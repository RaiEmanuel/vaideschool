package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.DisciplinaBEAN;
import bean.ProfessorBEAN;
import factory.ConnectionFactory;

public class TurmaDAO<T> implements BaseDAO<T>{

	@Override
	public void create(T object) {
		
	}
	
	@Override
	public List<T> read() {
		return null;
		
	}

	
	public List<T> readProfessores() {
		List<ProfessorBEAN> lista = new ArrayList<>();
		Connection conn = ConnectionFactory.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement("SELECT nome, matricula FROM professor");
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				ProfessorBEAN professorBEAN = new ProfessorBEAN();
				professorBEAN.setNome(rs.getString("nome"));
				professorBEAN.setMatricula(rs.getLong("matricula"));
				lista.add(professorBEAN);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return (List<T>) lista;
	}
	
	public List<T> readDisciplinas() {
		List<DisciplinaBEAN> lista = new ArrayList<>();
		Connection conn = ConnectionFactory.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement("SELECT nome FROM disciplina");
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				DisciplinaBEAN disciplinaBEAN = new DisciplinaBEAN();
				disciplinaBEAN.setNome(rs.getString("nome"));
				lista.add(disciplinaBEAN);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return (List<T>) lista;
	}

	@Override
	public void update(T object) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(T object) {
		// TODO Auto-generated method stub
		
	}
	
}

package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import bean.DisciplinaBEAN;
import bean.ProfessorBEAN;
import bean.TurmaBEAN;
import bean.Turma_has_AlunoBEAN;
import factory.ConnectionFactory;

public class TurmaDAO<T> implements BaseDAO<T> {

	@Override
	public int create(T object) {
		int retorno = 0;
		if (object instanceof TurmaBEAN) {
			try {
				TurmaBEAN turmaBEAN = (TurmaBEAN) object;
				Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn
						.prepareStatement("INSERT INTO turma VALUES (default, ?, ?::statusturma, ?, ?)");
				pst.setString(1, turmaBEAN.getLocal());
				pst.setString(2, String.valueOf(turmaBEAN.getStatus()));
				pst.setLong(3, turmaBEAN.getMatriculaProfessor());
				pst.setLong(4, turmaBEAN.getIdDisciplina());
				retorno = pst.executeUpdate();
				pst.close();
				conn.close();
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, e);
			}
		}
		return retorno;

	}

	@Override
	public List<T> read() {
		return null;

	}

	/*** OBS: COLOCAR NA TABELA ADEQUADA [PROFESSOR] ***/
	public List<T> readProfessores() {
		List<ProfessorBEAN> lista = new ArrayList<>();
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement("SELECT nome, matricula FROM professor");
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				ProfessorBEAN professorBEAN = new ProfessorBEAN();
				professorBEAN.setNome(rs.getString("nome"));
				professorBEAN.setMatricula(rs.getLong("matricula"));
				lista.add(professorBEAN);
			}
			rs.close();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return (List<T>) lista;
	}

	/*** OBS: COLOCAR NA TABELA ADEQUADA [DISCIPLINA] ***/
	public List<T> readDisciplinas() {
		List<DisciplinaBEAN> lista = new ArrayList<>();
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement("SELECT nome FROM disciplina");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				DisciplinaBEAN disciplinaBEAN = new DisciplinaBEAN();
				disciplinaBEAN.setNome(rs.getString("nome"));
				lista.add(disciplinaBEAN);
			}
			rs.close();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return (List<T>) lista;
	}

	@Override
	public int update(T object) {
		return 0;
		// TODO Auto-generated method stub

	}

	@Override
	public int delete(T object) {
		return 0;

		// TODO Auto-generated method stub

	}

	public long getIdTurmaLast() {
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement("SELECT idTurma FROM turma ORDER BY idturma desc LIMIT 1");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				return rs.getLong("idTurma");
			}
			rs.close();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return 0;
	}
	
	public int setStatus(Turma_has_AlunoBEAN turma_has_alunoBEAN) throws SQLException {
		int retorno = 0;
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement pst = conn.prepareStatement("UPDATE turma SET status = 'F' WHERE idTurma = ?");
		pst.setLong(1, turma_has_alunoBEAN.getIdTurma());
		retorno = pst.executeUpdate();
		pst.close();
		conn.close();
		return retorno;
	}

}

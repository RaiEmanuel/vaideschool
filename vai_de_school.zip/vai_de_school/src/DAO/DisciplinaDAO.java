package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import bean.DisciplinaBEAN;
import factory.ConnectionFactory;

public class DisciplinaDAO<T> implements BaseDAO<T>{

	@Override
	public int create(T object) {//instanceof  para verificar se e disciplina
		int retorno = 0;
		if(object instanceof DisciplinaBEAN) {
			DisciplinaBEAN disciplinaBEAN = (DisciplinaBEAN) object;
			
			try {
				Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement("INSERT INTO disciplina VALUES (default, ?, ?, ?)");
				pst.setString(1, disciplinaBEAN.getNome());
				pst.setByte(2, disciplinaBEAN.getCarga_horaria());
				pst.setByte(3, disciplinaBEAN.getHora_aula());
				retorno = pst.executeUpdate();
				pst.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return retorno;
		
	}

	@Override
	public List<T> read() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(T object) {
		return 0;
		// TODO Auto-generated method stub
		
	}

	@Override
	public int delete(T object) {
		return 0;
		// TODO Auto-generated method stub
		
	}
	
	public long getMatriculaProfessorByName(String nome) {
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst;
			pst = conn.prepareStatement("SELECT idDisciplina FROM disciplina WHERE nome LIKE ?");
			pst.setString(1, nome);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				return rs.getLong("idDisciplina");
			}
			rs.close();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}

		return 0;
	}
	
}

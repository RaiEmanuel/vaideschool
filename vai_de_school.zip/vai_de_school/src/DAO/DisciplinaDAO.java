package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import bean.DisciplinaBEAN;
import factory.ConnectionFactory;

public class DisciplinaDAO<T> implements BaseDAO<T>{

	@Override
	public void create(T object) {//instanceof  para verificar se e disciplina
		if(object instanceof DisciplinaBEAN) {
			DisciplinaBEAN disciplinaBEAN = (DisciplinaBEAN) object;
			
			try {
				Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement("INSERT INTO disciplina VALUES (default, ?, ?, ?)");
				pst.setString(1, disciplinaBEAN.getNome());
				pst.setByte(2, disciplinaBEAN.getCarga_horaria());
				pst.setByte(3, disciplinaBEAN.getHora_aula());
				pst.execute();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		
	}

	@Override
	public List<T> read() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(T object) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(T object) {
		// TODO Auto-generated method stub
		
	}
	
}

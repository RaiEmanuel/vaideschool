package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.DisciplinaBEAN;
import bean.ProfessorBEAN;
import factory.ConnectionFactory;

public class DisciplinaDAO<T> implements BaseDAO<T> {

	@Override
	public int create(T object) {// instanceof para verificar se e disciplina
		int retorno = 0;
		if (object instanceof DisciplinaBEAN) {
			DisciplinaBEAN disciplinaBEAN = (DisciplinaBEAN) object;

			try {
				Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement("INSERT INTO disciplina VALUES (default, ?, ?, ?)");
				pst.setString(1, disciplinaBEAN.getNome());
				pst.setByte(2, disciplinaBEAN.getCarga_horaria());
				pst.setByte(3, disciplinaBEAN.getHora_aula());
				retorno = pst.executeUpdate();
				pst.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return retorno;

	}

	@Override
	public List<T> read() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(T object) {
		int retorno = 0;
		try {
			if (object instanceof DisciplinaBEAN) {
				DisciplinaBEAN disciplinaBEAN = (DisciplinaBEAN) object;
				System.out.println(disciplinaBEAN.toString()+" ------------------------ ");
				Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement(
						"UPDATE disciplina SET nome = ?, carga_horaria = ?, hora_aula = ? WHERE idDisciplina = ?");
				pst.setString(1, disciplinaBEAN.getNome());
				pst.setByte(2, disciplinaBEAN.getCarga_horaria());
				pst.setByte(3, disciplinaBEAN.getHora_aula());
				pst.setLong(4, disciplinaBEAN.getIdDisciplina());
				retorno = pst.executeUpdate();
				pst.close();
				conn.close();
			}
		} catch (SQLException e) {
			System.out.println(e);
		}

		return retorno;
	}

	@Override
	public int delete(T object) {
		int retorno = 0;
		try {
			if (object instanceof DisciplinaBEAN) {
				DisciplinaBEAN disciplinaBEAN = (DisciplinaBEAN) object;
				System.out.println(disciplinaBEAN.toString()+" ------------------------ ");
				Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement(
						"DELETE FROM disciplina WHERE iddisciplina = ?");
				pst.setLong(1, disciplinaBEAN.getIdDisciplina());
				retorno = pst.executeUpdate();
				pst.close();
				conn.close();
			}
		} catch (SQLException e) {
			System.out.println(e);
		}

		return retorno;
	}

	public long getMatriculaProfessorByName(String nome) {
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst;
			pst = conn.prepareStatement("SELECT idDisciplina FROM disciplina WHERE nome LIKE ?");
			pst.setString(1, nome);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				return rs.getLong("idDisciplina");
			}
			rs.close();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}

		return 0;
	}

	public List<DisciplinaBEAN> getDataTableViewDisciplina(ProfessorBEAN professorBEAN) {
		List<DisciplinaBEAN> lista = new ArrayList<>();
		if(professorBEAN instanceof ProfessorBEAN) {
			try {
				Connection conn = ConnectionFactory.getConnection();
				/***PreparedStatement pst = conn.prepareStatement(
						"select dis.iddisciplina, dis.nome as disciplina, dis.carga_horaria as cargaHoraria, hora_aula as horaAula\r\n" + 
						"from turma as tur,professor as pro, disciplina as dis, horario as hor\r\n" + 
						"where tur.idturma = hor.turma_idTurma\r\n" + 
						"and tur.disciplina_idDisciplina = dis.idDisciplina\r\n" + 
						"and tur.professor_matriculaProfessor = pro.matricula\r\n"); 
						"and  pro.matricula = ?");***/
				PreparedStatement pst = conn.prepareStatement("select distinct disciplina.iddisciplina, disciplina.nome as disciplina, disciplina.carga_horaria as cargaHoraria, disciplina.hora_aula as horaAula \r\n" + 
						"from disciplina\r\n" + 
						"left join turma\r\n" + 
						"on turma.disciplina_iddisciplina = disciplina.iddisciplina\r\n" + 
						"left join professor\r\n" + 
						"on professor.matricula = turma.professor_matriculaprofessor\r\n" + 
						"left join horario\r\n" + 
						"on horario.turma_idturma = turma.idturma order by disciplina.nome ASC");
				//pst.setLong(1, professorBEAN.getMatricula());
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					DisciplinaBEAN disciplinaBEAN = new DisciplinaBEAN();
					disciplinaBEAN.setIdDisciplina(rs.getLong("idDisciplina"));
					disciplinaBEAN.setNome(rs.getString("disciplina"));
					disciplinaBEAN.setCarga_horaria(rs.getByte("cargaHoraria"));
					disciplinaBEAN.setHora_aula(rs.getByte("horaAula"));
					lista.add(disciplinaBEAN);
				}
				rs.close();
				pst.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		
		return lista;
	}

}

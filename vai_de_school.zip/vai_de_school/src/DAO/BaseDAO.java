package DAO;

import java.util.List;

public interface BaseDAO<T> {
	public int create(T object);
	public List<T> read();
	public int update(T object);
	public int delete(T object);
}

package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.AlunoBEAN;
import bean.DataTableViewEntrarTurmaBEAN;
import bean.PessoaBEAN;
import bean.TurmaBEAN;
import bean.Turma_has_AlunoBEAN;
import bean.DataTableViewHomeAlunoBEAN;
import bean.HistoricoBEAN;
import factory.ConnectionFactory;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;

public class AlunoDAO<T> implements BaseDAO<T>{

	@Override
	public int create(T object) {
		AlunoBEAN alunoBEAN = (AlunoBEAN) object;
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement ps = conn.prepareStatement("INSERT INTO aluno VALUES (default, ?, ?, ?, ?, ?, ?)");
			ps.setString(1, alunoBEAN.getNome());
			ps.setString(2, alunoBEAN.getRg());
			ps.setString(3, alunoBEAN.getSenha());
			ps.setString(4, alunoBEAN.getRua());
			ps.setShort(5, alunoBEAN.getNumero());
			ps.setString(6, alunoBEAN.getBairro());
			ps.executeUpdate();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return 0;
	}

	@Override
	public List<T> read() {
		
		return null;
	}

	@Override
	public int update(T object) {
		return 0;
		
	}

	@Override
	public int delete(T object) {
		return 0;
	
	}
	
	/* Retorna dados de preencher a tabela do home aluno com os dados das turmas que o aluno logado est� pagando */
	public List<DataTableViewHomeAlunoBEAN> getDataTableViewHomeAluno(DataTableViewHomeAlunoBEAN dataTableViewHomeAluno) {
		List<DataTableViewHomeAlunoBEAN> lista = new ArrayList<>();
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement ps = conn.prepareStatement("select t.idturma, d.idDisciplina, d.nome as disciplina ,t.local_aula as local ,h.horario as horario ,p.nome as professor from \r\n" + 
					"						  turma as t, disciplina as d,horario as h,professor as p, turma_has_aluno as tha, aluno as a where\r\n" + 
					"						  ((t.professor_matriculaprofessor = p.matricula and t.disciplina_idDisciplina = d.idDisciplina and h.turma_idTurma = t.idTurma \r\n" + 
					"						  and t.idTurma = tha.turma_idTurma and t.status = 'A' and tha.aluno_matriculaaluno = a.matricula) \r\n" + 
					"						  and a.matricula = ?)");
			ps.setLong(1, Long.parseLong(System.getProperty("matricula")));//setar valor do BEAN adequado
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				DataTableViewHomeAlunoBEAN tableViewHomeAlunoBEAN = new DataTableViewHomeAlunoBEAN();
				tableViewHomeAlunoBEAN.setIdTurma(rs.getLong("idTurma"));
				tableViewHomeAlunoBEAN.setDisciplina(rs.getString("disciplina"));
				tableViewHomeAlunoBEAN.setHorario(rs.getString("horario"));
				tableViewHomeAlunoBEAN.setLocal(rs.getString("local"));
				tableViewHomeAlunoBEAN.setProfessor(rs.getString("professor"));
				lista.add(tableViewHomeAlunoBEAN);
			}
			rs.close();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}

	public PessoaBEAN autenticar(PessoaBEAN pessoaBEAN) throws SQLException {
		Connection conn = ConnectionFactory.getConnection();
		AlunoBEAN alunoBEAN = new AlunoBEAN();
		PreparedStatement ps = conn
				.prepareStatement("SELECT * FROM aluno WHERE matricula = ? AND senha like ?");
		ps.setLong(1, pessoaBEAN.getMatricula());
		ps.setString(2, pessoaBEAN.getSenha());
		ResultSet rs = ps.executeQuery();
		pessoaBEAN = null;//para zerar e so receber algo se tiver alguem no banco
		
		if (rs.next()) {
			alunoBEAN.setMatricula(rs.getLong("matricula"));
			alunoBEAN.setNome(rs.getString("nome"));
			alunoBEAN.setRua(rs.getString("rua"));
			alunoBEAN.setBairro(rs.getString("bairro"));
			alunoBEAN.setNumero(rs.getShort("numero"));
			alunoBEAN.setRg(rs.getString("rg"));
			pessoaBEAN = alunoBEAN;
		} 
		rs.close();
		ps.close();
		conn.close();
		return pessoaBEAN;
	}
	
	public List<DataTableViewEntrarTurmaBEAN> getDataTableViewEntrarTurma() throws SQLException{
		List<DataTableViewEntrarTurmaBEAN> lista = new ArrayList<>();
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement ps = conn.prepareStatement("select distinct turma.idturma, disc.nome as disciplina, turma.local_aula as local, horario.horario, prof.nome as professor from aluno, turma\r\n" + 
				"inner join professor as prof\r\n" + 
				"on turma.professor_matriculaprofessor = prof.matricula\r\n" + 
				"inner join disciplina as disc\r\n" + 
				"on turma.disciplina_iddisciplina = disc.iddisciplina\r\n" + 
				"inner join horario\r\n" + 
				"on  horario.turma_idturma = turma.idturma\r\n" + 
				"where turma.status = 'A' and idturma not in (select distinct turma.idturma from aluno\r\n" + 
				"inner join turma_has_aluno as tha\r\n" + 
				"on aluno.matricula = tha.aluno_matriculaaluno\r\n" + 
				"inner join turma \r\n" + 
				"on tha.turma_idturma = turma.idturma\r\n" + 
				"where aluno.matricula = ?)");//aparecer somente se nao se cadastrou na turma ainda
		ps.setLong(1, Long.parseLong(System.getProperty("matricula")));
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			DataTableViewEntrarTurmaBEAN dataTableViewEntrarTurmaBEAN = new DataTableViewEntrarTurmaBEAN();
			dataTableViewEntrarTurmaBEAN.setDisciplina(rs.getString("disciplina"));
			dataTableViewEntrarTurmaBEAN.setHorario(rs.getString("local"));
			dataTableViewEntrarTurmaBEAN.setLocal(rs.getString("horario"));
			dataTableViewEntrarTurmaBEAN.setProfessor(rs.getString("professor"));
			dataTableViewEntrarTurmaBEAN.setIdTurma(rs.getLong("idTurma"));
			lista.add(dataTableViewEntrarTurmaBEAN);
		}
		rs.close();
		ps.close();
		conn.close();
		return lista;
	}
	/*bussiess delegate*/
	public void entrarTurma(Turma_has_AlunoBEAN turma_has_AlunoBEAN) throws SQLException {
		List<DataTableViewEntrarTurmaBEAN> lista = new ArrayList<>();
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement ps = conn.prepareStatement("INSERT INTO turma_has_aluno VALUES (?,?,?,?,?,?,?,?,?)");
		ps.setLong(1, turma_has_AlunoBEAN.getIdTurma());
		ps.setLong(2, turma_has_AlunoBEAN.getMatriculaAluno());
		ps.setDouble(3, turma_has_AlunoBEAN.getP1());
		ps.setDouble(4, turma_has_AlunoBEAN.getP2());
		ps.setDouble(5, turma_has_AlunoBEAN.getP3());
		ps.setDouble(6, turma_has_AlunoBEAN.getP4());
		ps.setShort(7, turma_has_AlunoBEAN.getFaltas());
		ps.setBoolean(8, turma_has_AlunoBEAN.isAprovado());
		ps.setDouble(9, turma_has_AlunoBEAN.getMedial_final());
		ps.execute();
		ps.close();
		conn.close();
	}
	
	public List<Turma_has_AlunoBEAN> getDataTableViewVisualizarTurmaProfessor(TurmaBEAN turmaBEAN) {
		List<Turma_has_AlunoBEAN> lista = new ArrayList<>();
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement("SELECT aluno.matricula, aluno.nome FROM aluno\r\n" + 
					"INNER JOIN turma_has_aluno\r\n" + 
					"ON aluno.matricula = turma_has_aluno.aluno_matriculaaluno\r\n" + 
					"INNER JOIN turma\r\n" + 
					"ON turma_has_aluno.turma_idturma = turma.idturma\r\n" + 
					"WHERE turma.idturma = ?");
			pst.setLong(1, turmaBEAN.getIdTurma());
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				Turma_has_AlunoBEAN alunoBEAN = new Turma_has_AlunoBEAN();
				alunoBEAN.setMatriculaAluno(rs.getLong("matricula"));
				alunoBEAN.setNomeAluno(rs.getString("nome"));
				lista.add(alunoBEAN);
			}
			rs.close();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return lista;
	}
	
	public List<HistoricoBEAN> getDataHistorico(AlunoBEAN alunoBEAN) throws SQLException{
		List<HistoricoBEAN> lista = new ArrayList<>();
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement pst = conn.prepareStatement("SELECT aluno.nome as aluno, professor.nome as professor, disciplina.nome as disciplina, p1, p2, p3, p4, media_final, faltas, aprovado, status\r\n" + 
				"FROM aluno\r\n" + 
				"INNER JOIN turma_has_aluno\r\n" + 
				"ON aluno.matricula = turma_has_aluno.aluno_matriculaaluno\r\n" + 
				"INNER JOIN turma\r\n" + 
				"ON turma_has_aluno.turma_idturma = turma.idturma\r\n" + 
				"INNER JOIN professor\r\n" + 
				"ON turma.professor_matriculaprofessor = professor.matricula\r\n" + 
				"INNER JOIN disciplina\r\n" + 
				"ON turma.disciplina_iddisciplina = disciplina.iddisciplina\r\n" + 
				"WHERE aluno.matricula = ?");
		pst.setLong(1, alunoBEAN.getMatricula());
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			HistoricoBEAN historicoBEAN = new HistoricoBEAN();
			historicoBEAN.setNomeALuno(rs.getString("aluno"));
			historicoBEAN.setNomeProfessor(rs.getString("professor"));
			historicoBEAN.setAprovado(rs.getBoolean("aprovado"));
			historicoBEAN.setFaltas(rs.getByte("faltas"));
			historicoBEAN.setMedia(rs.getDouble("media_final"));
			historicoBEAN.setP1(rs.getDouble("p1"));
			historicoBEAN.setP2(rs.getDouble("p2"));
			historicoBEAN.setP3(rs.getDouble("p3"));
			historicoBEAN.setP4(rs.getDouble("p4"));
			historicoBEAN.setStatus(rs.getString("status").charAt(0));
			historicoBEAN.setDisciplina(rs.getString("disciplina"));
			lista.add(historicoBEAN);
		}
		rs.close();
		pst.close();
		conn.close();
		
		return lista;
	}
	
}

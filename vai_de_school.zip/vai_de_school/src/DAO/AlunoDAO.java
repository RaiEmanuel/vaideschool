package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.AlunoBEAN;
import bean.PessoaBEAN;
import bean.DataTableViewHomeAlunoBEAN;
import factory.ConnectionFactory;
import javafx.beans.property.SimpleStringProperty;

public class AlunoDAO<T> implements BaseDAO<T>{

	@Override
	public void create(T object) {
		AlunoBEAN alunoBEAN = (AlunoBEAN) object;
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement ps = conn.prepareStatement("INSERT INTO aluno VALUES (default, ?, ?, ?, ?, ?, ?)");
			ps.setString(1, alunoBEAN.getNome());
			ps.setString(2, alunoBEAN.getRg());
			ps.setString(3, alunoBEAN.getSenha());
			ps.setString(4, alunoBEAN.getRua());
			ps.setShort(5, alunoBEAN.getNumero());
			ps.setString(6, alunoBEAN.getBairro());
			ps.execute();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		
	}

	@Override
	public List<T> read() {
		
		return null;
	}

	@Override
	public void update(T object) {
		
	}

	@Override
	public void delete(T object) {
	
	}
	
	/* Retorna dados de preencher a tabela do home aluno com os dados das turmas que o aluno logado est� pagando */
	public List<DataTableViewHomeAlunoBEAN> getDataTableViewHomeAluno(DataTableViewHomeAlunoBEAN dataTableViewHomeAluno) throws SQLException {
		List<DataTableViewHomeAlunoBEAN> lista = new ArrayList<>();
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement ps = conn.prepareStatement("select d.idDisciplina, d.nome as disciplina ,t.local_aula as local ,h.horario as horario ,p.nome as professor from \r\n" + 
				"						  turma as t, disciplina as d,horario as h,professor as p, turma_has_aluno as tha, aluno as a where\r\n" + 
				"						  ((t.professor_matriculaprofessor = p.matricula and t.disciplina_idDisciplina = d.idDisciplina and h.turma_idTurma = t.idTurma \r\n" + 
				"						  and t.idTurma = tha.turma_idTurma and tha.aluno_matriculaaluno = a.matricula) \r\n" + 
				"						  and a.matricula = ?)");
		ps.setLong(1, dataTableViewHomeAluno.getIdAlunoLogado());//setar valor do BEAN adequado
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			DataTableViewHomeAlunoBEAN tableViewHomeAlunoBEAN = new DataTableViewHomeAlunoBEAN();
			tableViewHomeAlunoBEAN.setDisciplina(new SimpleStringProperty(rs.getString("disciplina")));
			tableViewHomeAlunoBEAN.setHorario(new SimpleStringProperty(rs.getString("local")));
			tableViewHomeAlunoBEAN.setLocal(new SimpleStringProperty(rs.getString("horario")));
			tableViewHomeAlunoBEAN.setProfessor(new SimpleStringProperty(rs.getString("professor")));
			lista.add(tableViewHomeAlunoBEAN);
		}
		rs.close();
		ps.close();
		conn.close();
		return lista;
	}

	public PessoaBEAN autenticar(PessoaBEAN pessoaBEAN) throws SQLException {
		Connection conn = ConnectionFactory.getConnection();
		AlunoBEAN alunoBEAN = new AlunoBEAN();
		
		PreparedStatement ps = conn
				.prepareStatement("SELECT * FROM aluno WHERE matricula = ? AND senha like ?");
		ps.setLong(1, pessoaBEAN.getMatricula());
		ps.setString(2, pessoaBEAN.getSenha());
		ResultSet rs = ps.executeQuery();
		pessoaBEAN = null;//para zerar e so receber algo se tiver alguem no banco
		
		if (rs.next()) {
			alunoBEAN.setMatricula(rs.getLong("matricula"));
			alunoBEAN.setNome(rs.getString("nome"));
			alunoBEAN.setRua(rs.getString("rua"));
			alunoBEAN.setBairro(rs.getString("bairro"));
			alunoBEAN.setNumero(rs.getShort("numero"));
			alunoBEAN.setRg(rs.getString("rg"));
			pessoaBEAN = alunoBEAN;
		} 
		rs.close();
		ps.close();
		conn.close();
		return pessoaBEAN;
	}
	
	
}

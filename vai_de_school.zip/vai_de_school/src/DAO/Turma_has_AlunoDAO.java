package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import bean.Turma_has_AlunoBEAN;
import factory.ConnectionFactory;

public class Turma_has_AlunoDAO<T> implements BaseDAO<T>{

	@Override
	public int create(T object) {
		int retornoUpdateTurma = 0, retornoUpdateTurmaHasAluno = 0,  retornoUpdateTurmaHasAluno2 = 0;
		Turma_has_AlunoBEAN turma_has_alunoBEAN = (Turma_has_AlunoBEAN) object;
			//System.out.println(turma_has_alunoBEAN.toString());
			
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement ps = conn.prepareStatement("update turma_has_aluno "
								+"set p1 = ?, p2 = ?, p3 = ?, p4 = ?, faltas = ?"
								+" where turma_idTurma = ? and aluno_matriculaaluno = ?");
			ps.setDouble(1, turma_has_alunoBEAN.getP1());
			ps.setDouble(2, turma_has_alunoBEAN.getP2());
			ps.setDouble(3, turma_has_alunoBEAN.getP3());
			ps.setDouble(4, turma_has_alunoBEAN.getP4());
			ps.setByte(5, turma_has_alunoBEAN.getFaltas());
			ps.setLong(6,turma_has_alunoBEAN.getIdTurma());
			ps.setLong(7,turma_has_alunoBEAN.getMatriculaAluno());
			retornoUpdateTurma = ps.executeUpdate();
			ps.close();
			
			
			PreparedStatement ps2 = conn.prepareStatement("update turma_has_aluno"
								+ " set media_final = calcula_media_final(p1,p2,p3,p4)"
								+ " where turma_idTurma = ? and aluno_matriculaaluno = ?");
			//ps2.setDouble(1, turma_has_alunoBEAN.getP1());
			//ps2.setDouble(2, turma_has_alunoBEAN.getP2());
			///ps2.setDouble(3, turma_has_alunoBEAN.getP3());
			//ps2.setDouble(4, turma_has_alunoBEAN.getP4());
			ps2.setLong(1, turma_has_alunoBEAN.getIdTurma());
			ps2.setDouble(2, turma_has_alunoBEAN.getMatriculaAluno());
			retornoUpdateTurmaHasAluno = ps2.executeUpdate();
			ps2.close();
			
			PreparedStatement ps3 = conn.prepareStatement("update turma_has_aluno"
								+ " set aprovado = teste_aprovado(media_final,p4,faltas,pega_qtd_maxima_falta(?))"
								+ " where turma_idTurma = ? and aluno_matriculaaluno = ?");
			ps3.setLong(1, turma_has_alunoBEAN.getMatriculaAluno());
			ps3.setLong(2, turma_has_alunoBEAN.getIdTurma());
			ps3.setLong(3, turma_has_alunoBEAN.getMatriculaAluno());
			retornoUpdateTurmaHasAluno2 = ps3.executeUpdate();
			ps3.close();
					
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		/*
		System.out.println("gambiarra: "+ retornoUpdateTurma);
		System.out.println("gambiarra: "+ retornoUpdateTurmaHasAluno);
		System.out.println("gambiarra: "+ retornoUpdateTurmaHasAluno2);*/
		return retornoUpdateTurma * retornoUpdateTurmaHasAluno * retornoUpdateTurmaHasAluno2;
	}

	@Override
	public List<T> read() {
		
		return null;
	}

	@Override
	public int update(T object) {
		
		return 0;
	}

	@Override
	public int delete(T object) {
		
		return 0;
	}

}

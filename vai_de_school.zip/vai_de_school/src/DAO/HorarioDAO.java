package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import bean.HorarioBEAN;
import bean.ProfessorBEAN;
import factory.ConnectionFactory;

public class HorarioDAO<T> implements BaseDAO<T>{

	@Override
	public int create(T object) {
		int retorno = 0;
		try {
			HorarioBEAN horarioBEAN = (HorarioBEAN) object;
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement("INSERT INTO horario VALUES (default, ?, ?)");
			pst.setString(1, horarioBEAN.getHorario());
			pst.setLong(2, horarioBEAN.getIdTurma());
			retorno = pst.executeUpdate();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return retorno;
	}

	@Override
	public List<T> read() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(T object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(T object) {
		// TODO Auto-generated method stub
		return 0;
	}

}

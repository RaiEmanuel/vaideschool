package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import bean.PessoaBEAN;
import bean.ProfessorBEAN;
import factory.ConnectionFactory;

public class ProfessorDAO<T> implements BaseDAO<T> {

	@Override
	public void create(T object) {
		try {
			ProfessorBEAN professorBEAN = new ProfessorBEAN();
			professorBEAN = (ProfessorBEAN) object;
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement ps = conn.prepareStatement("INSERT INTO professor VALUES (default, ?, ?, ?, ?, ?)");
			ps.setString(1, professorBEAN.getNome());
			ps.setString(2, professorBEAN.getRua());
			ps.setShort(3, professorBEAN.getNumero());
			ps.setString(4, professorBEAN.getBairro());
			ps.setString(5, professorBEAN.getSenha());
			ps.execute();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

	@Override
	public List<T> read() {
		return null;
		/*lista = new ArrayList<ProfessorBEAN>();
		conn = ConnectionFactory.getConnection();
		try {
			ps = conn.prepareStatement(READ_SQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				professorAux = new ProfessorBEAN();
				professorAux.setNome(rs.getString("nome"));
				professorAux.setBairro(rs.getString("bairro"));
				// professorAux.setNumero((short) rs.getInt("numero"));
				professorAux.setRua(rs.getString("rua"));
				lista.add(professorAux);
			}
			rs.close();
			ps.close();
			conn.close();
			professorAux = null;
		} catch (NullPointerException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		}

		return (List<T>) lista;*/
	}

	@Override
	public void update(T object) {

	}

	@Override
	public void delete(T object) {

	}

	public PessoaBEAN autenticar(PessoaBEAN pessoaBEAN) throws SQLException {
		ProfessorBEAN professorBEAN = new ProfessorBEAN();
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM professor WHERE matricula = ? AND senha like ?");
		ps.setLong(1, pessoaBEAN.getMatricula());
		ps.setString(2, pessoaBEAN.getSenha());

		ResultSet rs = ps.executeQuery();
		pessoaBEAN = null;// para zerar e so receber algo se tiver alguem no banco

		if (rs.next()) {
			professorBEAN.setMatricula(rs.getLong("matricula"));
			professorBEAN.setNome(rs.getString("nome"));
			professorBEAN.setRua(rs.getString("rua"));
			professorBEAN.setBairro(rs.getString("bairro"));
			professorBEAN.setNumero(rs.getShort("numero"));
			pessoaBEAN = professorBEAN;
		}
		rs.close();
		ps.close();
		conn.close();
		return pessoaBEAN;
	}

}

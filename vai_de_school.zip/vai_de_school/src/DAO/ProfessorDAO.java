package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.DataTableViewHomeProfessorBEAN;
import bean.PessoaBEAN;
import bean.ProfessorBEAN;
import factory.ConnectionFactory;
import javafx.beans.property.SimpleStringProperty;

public class ProfessorDAO<T> implements BaseDAO<T> {

	@Override
	public int create(T object) {
		int retorno = 0;
		try {
			ProfessorBEAN professorBEAN = new ProfessorBEAN();
			professorBEAN = (ProfessorBEAN) object;
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement("INSERT INTO professor VALUES (default, ?, ?, ?, ?, ?)");
			pst.setString(1, professorBEAN.getNome());
			pst.setString(2, professorBEAN.getRua());
			pst.setShort(3, professorBEAN.getNumero());
			pst.setString(4, professorBEAN.getBairro());
			pst.setString(5, professorBEAN.getSenha());
			retorno = pst.executeUpdate();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return retorno;
	}

	@Override
	public List<T> read() {
		return null;
		/*lista = new ArrayList<ProfessorBEAN>();
		conn = ConnectionFactory.getConnection();
		try {
			ps = conn.prepareStatement(READ_SQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				professorAux = new ProfessorBEAN();
				professorAux.setNome(rs.getString("nome"));
				professorAux.setBairro(rs.getString("bairro"));
				// professorAux.setNumero((short) rs.getInt("numero"));
				professorAux.setRua(rs.getString("rua"));
				lista.add(professorAux);
			}
			rs.close();
			ps.close();
			conn.close();
			professorAux = null;
		} catch (NullPointerException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		}

		return (List<T>) lista;*/
	}

	@Override
	public int update(T object) {
		return 0;

	}

	@Override
	public int delete(T object) {
		return 0;

	}

	public PessoaBEAN autenticar(PessoaBEAN pessoaBEAN) {
		try {
			ProfessorBEAN professorBEAN = new ProfessorBEAN();
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement ps;
			ps = conn.prepareStatement("SELECT * FROM professor WHERE matricula = ? AND senha like ?");
			ps.setLong(1, pessoaBEAN.getMatricula());
			ps.setString(2, pessoaBEAN.getSenha());
			ResultSet rs = ps.executeQuery();
			pessoaBEAN = null;// para zerar e so receber algo se tiver alguem no banco
			if (rs.next()) {
				professorBEAN.setMatricula(rs.getLong("matricula"));
				professorBEAN.setNome(rs.getString("nome"));
				professorBEAN.setRua(rs.getString("rua"));
				professorBEAN.setBairro(rs.getString("bairro"));
				professorBEAN.setNumero(rs.getShort("numero"));
				pessoaBEAN = professorBEAN;
			}
			rs.close();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		return pessoaBEAN;
	}

	public long getMatriculaProfessorByName(String nome) {
		
		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement("SELECT matricula FROM professor WHERE nome LIKE ?");
			pst.setString(1, nome);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				return rs.getLong("matricula");
			}
			rs.close();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			System.out.println(e);
		}

		return 0;
	}
	
	public List<DataTableViewHomeProfessorBEAN> getDataTableViewHomeProfessor(ProfessorBEAN ProfessorBEAN) throws SQLException {
		List<DataTableViewHomeProfessorBEAN> lista = new ArrayList<>();
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement ps = conn.prepareStatement("select tur.idTurma, dis.nome as disciplina,tur.local_aula as local, hor.horario as horario\r\n" + 
				"							  from turma as tur,professor as pro, disciplina as dis, horario as hor\r\n" + 
				"							  where tur.idturma = hor.turma_idTurma \r\n" + 
				"							  and tur.disciplina_idDisciplina = dis.idDisciplina\r\n" + 
				"							  and tur.professor_matriculaProfessor = pro.matricula \r\n" + 
				"							  and  pro.matricula = ? and tur.status = 'A'");
		ps.setLong(1, ProfessorBEAN.getMatricula());//setar valor do BEAN adequado
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			DataTableViewHomeProfessorBEAN tableViewHomeProfessorBEAN = new DataTableViewHomeProfessorBEAN();
			tableViewHomeProfessorBEAN.setIdTurma(rs.getLong("idTurma"));
			tableViewHomeProfessorBEAN.setDisciplina(rs.getString("disciplina"));
			tableViewHomeProfessorBEAN.setLocal(rs.getString("local"));
			tableViewHomeProfessorBEAN.setHorario(rs.getString("horario"));
			lista.add(tableViewHomeProfessorBEAN);
		}
		rs.close();
		ps.close();
		conn.close();
		return lista;
	}
	
}

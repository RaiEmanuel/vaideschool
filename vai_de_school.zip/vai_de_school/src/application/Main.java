package application;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class Main extends Application {

	private static Stage palco;
	
	@Override
	public void start(Stage palco) throws IOException {
		palco.setTitle("Vai de school");
		setPalco(palco);
		viewLogin();
		//viewCadastroDisciplina();
		//viewCadastroTurma();
	}
	
	public static void setPalco(Stage palcop) {
		palco = palcop;
	}
	
	public void viewLogin() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/login.fxml"));
			//FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/homeAluno.fxml"));
			Pane principal = loader.load();
			
			Scene scene = new Scene(principal);
			
			palco.setScene(scene);
			palco.show();
			
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	public void viewCadastroDisciplina() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/cadastroDisciplina.fxml"));
			//FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/homeAluno.fxml"));
			Pane principal = loader.load();
			
			Scene scene = new Scene(principal);
			
			palco.setScene(scene);
			palco.show();
			
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	
	public void viewCadastroAlunoProfessor() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/cadastroAlunoProfessor.fxml"));
		Pane novo = loader.load();
		
		Scene scene = new Scene(novo);
		
		palco.setTitle("cadastro");
		palco.setScene(scene);
		palco.show();
	}
	
	public void viewHomeAluno() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/homeAluno.fxml"));
		Pane novo = loader.load();
		
		Scene scene = new Scene(novo);
		
		palco.setTitle("home Aluno");
		palco.setScene(scene);
		palco.show();
	}
	
	public void viewEntrarTurma() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/cadastroAlunoHasTurma.fxml"));
		Pane novo = loader.load();
		
		Scene scene = new Scene(novo);
		
		palco.setTitle("home Aluno");
		palco.setScene(scene);
		palco.show();
	}
	
	public void viewCadastroTurma() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/cadastroTurma.fxml"));
		Pane novo = loader.load();
		
		Scene scene = new Scene(novo);
		
		palco.setTitle("Cadastro de turma");
		palco.setScene(scene);
		palco.show();
	}
	
	public static void main(String[] args) {
		launch();
	}
	
	
	
}

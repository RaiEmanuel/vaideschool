package model;

import java.util.ArrayList;
import java.util.List;

import DAO.DisciplinaDAO;
import DAO.HorarioDAO;
import DAO.ProfessorDAO;
import DAO.TurmaDAO;
import bean.DisciplinaBEAN;
import bean.HorarioBEAN;
import bean.ProfessorBEAN;
import bean.TurmaBEAN;

public class TurmaModel {

	public int cadastrar(TurmaBEAN turmaBEAN) {
		TurmaDAO<TurmaBEAN> turmaDAO = new TurmaDAO<>();
		return turmaDAO.create(turmaBEAN);
	}
	
	public int cadastrarHorario(HorarioBEAN turmaBEAN) {
		HorarioDAO<HorarioBEAN> horarioDAO = new HorarioDAO<>();
		return horarioDAO.create(turmaBEAN);
	}

	public long getMatriculaProfessorByName(String nome) {
		ProfessorDAO<ProfessorBEAN> professorDAO = new ProfessorDAO<>();
		return professorDAO.getMatriculaProfessorByName(nome);
	}
	
	public long getidDisciplinaByName(String nome) {
		DisciplinaDAO<DisciplinaBEAN> disciplinaDAO = new DisciplinaDAO<>();
		return disciplinaDAO.getMatriculaProfessorByName(nome);
	}
	
	public List<String> getProfessores() {
		TurmaDAO<ProfessorBEAN> turmaDAO = new TurmaDAO<>();
		List<String>lista = new ArrayList<>();
		for(ProfessorBEAN professorBEAN : turmaDAO.readProfessores()) {
			lista.add(professorBEAN.getNome());
		}
		return lista;
	}

	public List<String> getDisciplinas() {
		TurmaDAO<DisciplinaBEAN> turmaDAO = new TurmaDAO<>();
		List<String>lista = new ArrayList<>();
		for(DisciplinaBEAN disciplinaBEAN : turmaDAO.readDisciplinas()) {
			lista.add(disciplinaBEAN.getNome());
		}
		return lista;
	}
	
	public long getIdTurmaLast() {
		TurmaDAO<TurmaBEAN> turmaDAO = new TurmaDAO<>();
		return turmaDAO.getIdTurmaLast();
	}
	
}

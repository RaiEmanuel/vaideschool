package model;

import java.util.ArrayList;
import java.util.List;

import DAO.TurmaDAO;
import bean.DisciplinaBEAN;
import bean.ProfessorBEAN;

public class TurmaModel {

	public void cadastrar() {

	}

	public List<String> getProfessores() {
		TurmaDAO<ProfessorBEAN> turmaDAO = new TurmaDAO<>();
		List<String>lista = new ArrayList<>();
		for(ProfessorBEAN professorBEAN : turmaDAO.readProfessores()) {
			lista.add(professorBEAN.getNome());
		}
		return lista;
	}

	public List<String> getDisciplinas() {
		TurmaDAO<DisciplinaBEAN> turmaDAO = new TurmaDAO<>();
		List<String>lista = new ArrayList<>();
		for(DisciplinaBEAN disciplinaBEAN : turmaDAO.readDisciplinas()) {
			lista.add(disciplinaBEAN.getNome());
		}
		return lista;
	}
	
}

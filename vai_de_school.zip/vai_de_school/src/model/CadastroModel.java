package model;

import java.sql.SQLException;

import DAO.AlunoDAO;
import DAO.ProfessorDAO;
import bean.AlunoBEAN;
import bean.PessoaBEAN;
import bean.ProfessorBEAN;

public class CadastroModel {/*   usar instanceof    */
	public void cadastrar(PessoaBEAN pessoaBEAN) throws SQLException {
		if(pessoaBEAN.getNivelAcesso().equals("aluno")) {
			AlunoDAO<AlunoBEAN> alunoDAO = new AlunoDAO<>();
			alunoDAO.create((AlunoBEAN) pessoaBEAN);
		}else if(pessoaBEAN.getNivelAcesso().equals("professor")) {
			ProfessorDAO<ProfessorBEAN> professorDAO = new ProfessorDAO<>();
			professorDAO.create((ProfessorBEAN) pessoaBEAN);
		}
	}
}

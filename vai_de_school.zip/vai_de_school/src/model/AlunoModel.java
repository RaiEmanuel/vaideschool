package model;

import java.sql.SQLException;
import java.util.List;

import DAO.AlunoDAO;
import bean.DataTableViewHomeAlunoBEAN;

public class AlunoModel {
	public List<DataTableViewHomeAlunoBEAN> getDataTableViewHomeAluno(DataTableViewHomeAlunoBEAN dataTableViewHomeAluno) throws SQLException {
		AlunoDAO<DataTableViewHomeAlunoBEAN> alunoDAO = new AlunoDAO<>();
		return alunoDAO.getDataTableViewHomeAluno(dataTableViewHomeAluno);
	}
}

package model;

import java.sql.SQLException;
import java.util.List;

import DAO.AlunoDAO;
import bean.AlunoBEAN;
import bean.DataTableViewEntrarTurmaBEAN;
import bean.DataTableViewHomeAlunoBEAN;
import bean.HistoricoBEAN;
import bean.TurmaBEAN;
import bean.Turma_has_AlunoBEAN;

public class AlunoModel {
	public List<DataTableViewHomeAlunoBEAN> getDataTableViewHomeAluno(DataTableViewHomeAlunoBEAN dataTableViewHomeAluno) throws SQLException {
		AlunoDAO<DataTableViewHomeAlunoBEAN> alunoDAO = new AlunoDAO<>();
		return alunoDAO.getDataTableViewHomeAluno(dataTableViewHomeAluno);
	}
	
	public List<DataTableViewEntrarTurmaBEAN> getDataTableViewEntrarTurma(String nome) throws SQLException{
		AlunoDAO<DataTableViewEntrarTurmaBEAN> alunoDAO = new AlunoDAO<>();
		return alunoDAO.getDataTableViewEntrarTurma(nome);
	}
	
	public int entrarTurma(Turma_has_AlunoBEAN turma_has_AlunoBEAN) throws SQLException {
		AlunoDAO<Turma_has_AlunoBEAN> alunoDAO = new AlunoDAO<>();
		return alunoDAO.entrarTurma(turma_has_AlunoBEAN);
	}
	
	public List<Turma_has_AlunoBEAN> getDataTableViewVisualizarTurmaProfessor(TurmaBEAN turmaBEAN) {
		AlunoDAO<TurmaBEAN> alunoDAO = new AlunoDAO<>();
		return alunoDAO.getDataTableViewVisualizarTurmaProfessor(turmaBEAN);
	}
	
	public List<HistoricoBEAN> getDataHistorico(AlunoBEAN alunoBEAN) throws SQLException{
		AlunoDAO<HistoricoBEAN> alunoDAO = new AlunoDAO<>();
		return alunoDAO.getDataHistorico(alunoBEAN);
	}
	
	public int create(AlunoBEAN alunoBEAN) {
		AlunoDAO<AlunoBEAN> alunoDAO = new AlunoDAO<AlunoBEAN>();
		return alunoDAO.create(alunoBEAN);
	}
}

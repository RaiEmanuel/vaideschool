package model;

import java.sql.SQLException;

import DAO.AlunoDAO;

import DAO.ProfessorDAO;
import bean.AlunoBEAN;
import bean.PessoaBEAN;
import bean.ProfessorBEAN;

public class LoginModel {
	public PessoaBEAN autenticar(PessoaBEAN pessoaBEAN) throws SQLException {
		AlunoDAO<AlunoBEAN> alunoDAO = new AlunoDAO<>();
		ProfessorDAO<ProfessorBEAN> professorDAO = new ProfessorDAO<>();
		
		if(pessoaBEAN.getNivelAcesso().equals("aluno")) {
			return alunoDAO.autenticar(pessoaBEAN);
		}else if(pessoaBEAN.getNivelAcesso().equals("professor")) {
			return professorDAO.autenticar(pessoaBEAN);
		}
		return null;
	}
}

package model;

import DAO.DisciplinaDAO;
import bean.DisciplinaBEAN;

public class DisciplinaModel {
	public void cadastrar(DisciplinaBEAN disciplinaBEAN) {
		DisciplinaDAO<DisciplinaBEAN> disciplinaDAO = new DisciplinaDAO<>(); 
		disciplinaDAO.create(disciplinaBEAN);
		System.out.println(disciplinaBEAN.toString());
	}
}

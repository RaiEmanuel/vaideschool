package model;

import java.util.List;

import DAO.DisciplinaDAO;
import bean.DisciplinaBEAN;
import bean.ProfessorBEAN;

public class DisciplinaModel {
	public int create(DisciplinaBEAN disciplinaBEAN) {
		DisciplinaDAO<DisciplinaBEAN> disciplinaDAO = new DisciplinaDAO<>(); 
		return disciplinaDAO.create(disciplinaBEAN);
	}
	
	public int atualizar(DisciplinaBEAN disciplinaBEAN) {
		DisciplinaDAO<DisciplinaBEAN> disciplinaDAO = new DisciplinaDAO<>(); 
		System.out.println(disciplinaBEAN.toString());
		return disciplinaDAO.update(disciplinaBEAN);
	}
	
	public int excluir(DisciplinaBEAN disciplinaBEAN) {
		DisciplinaDAO<DisciplinaBEAN> disciplinaDAO = new DisciplinaDAO<>(); 
		return disciplinaDAO.delete(disciplinaBEAN);
	}
	
	public List<DisciplinaBEAN> getDataTableViewDisciplina(ProfessorBEAN professorBEAN) {
		DisciplinaDAO<ProfessorBEAN> disciplinaDAO = new DisciplinaDAO<>();
		return disciplinaDAO.getDataTableViewDisciplina(professorBEAN);
	}
}

package model;

import java.sql.SQLException;
import java.util.List;

import DAO.AlunoDAO;
import DAO.ProfessorDAO;
import bean.DataTableViewHomeAlunoBEAN;
import bean.DataTableViewHomeProfessorBEAN;

public class ProfessorModel {
	public List<DataTableViewHomeProfessorBEAN> getDataTableViewHomeProfessor(DataTableViewHomeProfessorBEAN dataTableViewHomeProfessor) throws SQLException {
		ProfessorDAO<DataTableViewHomeProfessorBEAN> professorDAO = new ProfessorDAO<>();
		return professorDAO.getDataTableViewHomeProfessor(dataTableViewHomeProfessor);
	}
}

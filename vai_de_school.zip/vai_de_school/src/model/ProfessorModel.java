package model;

import java.sql.SQLException;
import java.util.List;

import DAO.AlunoDAO;
import DAO.ProfessorDAO;
import DAO.Turma_has_AlunoDAO;
import bean.DataTableViewHomeAlunoBEAN;
import bean.DataTableViewHomeProfessorBEAN;
import bean.ProfessorBEAN;
import bean.Turma_has_AlunoBEAN;

public class ProfessorModel {
	public List<DataTableViewHomeProfessorBEAN> getDataTableViewHomeProfessor(ProfessorBEAN professorBEAN) throws SQLException {
		ProfessorDAO<ProfessorBEAN> professorDAO = new ProfessorDAO<>();
		return professorDAO.getDataTableViewHomeProfessor(professorBEAN);
	}
		
	public int setNotas(Turma_has_AlunoBEAN turma_has_alunoBEAN)
	{
		Turma_has_AlunoDAO<Turma_has_AlunoBEAN> turma_has_alunoDAO = new Turma_has_AlunoDAO<>();
		//System.out.println("chegou at� aqui22222");
		//System.out.println(turma_has_alunoBEAN.toString());
		return turma_has_alunoDAO.create(turma_has_alunoBEAN);
		
	}
	
	public int create(ProfessorBEAN professorBEAN) {
		ProfessorDAO<ProfessorBEAN> professorDAO = new ProfessorDAO<>();
		return professorDAO.create(professorBEAN);
	}
	
}

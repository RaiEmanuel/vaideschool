package utility;

import java.util.List;

import javafx.scene.control.ButtonBase;
import javafx.scene.control.Control;
import javafx.scene.control.TextField;

public class EnableDisableControls {

	public static void enable(List<Control> control) {// lista com botoes para bloquear
		for (Control c : control) {
			if (c instanceof TextField) {
				TextField campo = (TextField) c;
				campo.setDisable(false);
			}else if(c instanceof ButtonBase) {
				ButtonBase button = (ButtonBase) c;
				button.setDisable(false);
			}
		}
	}

	public static void disable(List<Control> control) {
		for (Control c : control) {
			if (c instanceof TextField) {
				TextField campo = (TextField) c;
				campo.setDisable(true);
			}else if(c instanceof ButtonBase) {
				ButtonBase button = (ButtonBase) c;
				button.setDisable(true);
			}
		}
	}

}

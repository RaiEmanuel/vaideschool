package controller;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import application.Main;
import bean.DisciplinaBEAN;
import bean.ProfessorBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import model.DisciplinaModel;
import utility.EnableDisableControls;

public class EditarExcluirDisciplinaController implements Initializable {
	@FXML
	private Button btnExcluir, btnAtualizar, btnNovo;
	@FXML
	private TextField textFieldDisciplina, textFieldCargaHoraria, textFieldHoraAula, textFieldIdDisciplina;
	@FXML
	private TableView<DisciplinaBEAN> tabela;
	@FXML
	private TableColumn<DisciplinaBEAN, Long> idDisciplina;
	@FXML
	private TableColumn<DisciplinaBEAN, String> disciplina;
	@FXML
	private TableColumn<DisciplinaBEAN, Byte> cargaHoraria;
	@FXML
	private TableColumn<DisciplinaBEAN, Byte> horaAula;
	Main view;

	@FXML
	protected void excluir(ActionEvent event) {
		List<Control> lista = new ArrayList<>();
		lista.add(textFieldIdDisciplina);
		lista.add(textFieldDisciplina);
		lista.add(textFieldCargaHoraria);
		lista.add(textFieldHoraAula);
		lista.add(btnAtualizar);
		lista.add(btnExcluir);
		EnableDisableControls.disable(lista);
		// desativa campos
		lista.add(btnNovo);
		EnableDisableControls.enable(lista);
		//ativa campos
		DisciplinaModel disciplinaModel = new DisciplinaModel();
		DisciplinaBEAN disciplinaBEAN = new DisciplinaBEAN();
		disciplinaBEAN.setIdDisciplina(Long.parseLong(textFieldIdDisciplina.getText()));
		System.out.println("excluir: "+disciplinaModel.excluir(disciplinaBEAN));
		//initialize(null, null);
		tabela.refresh();
	}

	@FXML
	protected void atualizar(ActionEvent event) {
		List<Control> lista = new ArrayList<>();
		lista.add(textFieldIdDisciplina);
		lista.add(textFieldDisciplina);
		lista.add(textFieldCargaHoraria);
		lista.add(textFieldHoraAula);
		lista.add(btnAtualizar);
		lista.add(btnExcluir);
		EnableDisableControls.disable(lista);
		lista.clear();
		// desativa campos
		lista.add(btnNovo);
		EnableDisableControls.enable(lista);
		//ativa campos
		DisciplinaModel disciplinaModel = new DisciplinaModel();
		DisciplinaBEAN disciplinaBEAN = new DisciplinaBEAN();
		disciplinaBEAN.setIdDisciplina(Long.parseLong(textFieldIdDisciplina.getText()));
		disciplinaBEAN.setNome(textFieldDisciplina.getText());
		disciplinaBEAN.setCarga_horaria(Byte.parseByte(textFieldCargaHoraria.getText()));
		disciplinaBEAN.setHora_aula(Byte.parseByte(textFieldHoraAula.getText()));
		disciplinaModel.atualizar(disciplinaBEAN);
		//initialize(null, null);
		tabela.refresh();
	}

	@FXML
	protected void novo(ActionEvent event) {
		List<Control> lista = new ArrayList<>();
		lista.add(textFieldIdDisciplina);
		lista.add(textFieldDisciplina);
		lista.add(textFieldCargaHoraria);
		lista.add(textFieldHoraAula);
		lista.add(btnAtualizar);
		lista.add(btnExcluir);
		EnableDisableControls.enable(lista);
		lista.clear();
		//ativa campos
		lista.add(btnNovo);
		EnableDisableControls.disable(lista);
		//desativa campos
	}

	@FXML
	protected void voltar(ActionEvent event) {
		view = new Main();
		view.viewHomeProfessor();
	}
	
	/***   COLOCAR EVENTOS PARA KEYLISTENER     ***/
	@FXML
	protected void setCampos(MouseEvent event) {
		DisciplinaBEAN disciplinaBEAN;
		disciplinaBEAN = tabela.getSelectionModel().getSelectedItem();
		if(disciplinaBEAN != null) {//verifica se seleciona alguma disciplina na tabela
			textFieldIdDisciplina.setText(String.valueOf(disciplinaBEAN.getIdDisciplina()));
			textFieldDisciplina.setText(disciplinaBEAN.getNome());
			textFieldCargaHoraria.setText(String.valueOf(disciplinaBEAN.getCarga_horaria()));
			textFieldHoraAula.setText(String.valueOf(disciplinaBEAN.getHora_aula()));
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		idDisciplina.setCellValueFactory(new PropertyValueFactory<>("idDisciplina"));
		disciplina.setCellValueFactory(new PropertyValueFactory<>("nome"));
		cargaHoraria.setCellValueFactory(new PropertyValueFactory<>("carga_horaria"));
		horaAula.setCellValueFactory(new PropertyValueFactory<>("hora_aula"));
		try {
			tabela.setItems(getDataTableViewDisciplina());
		} catch (SQLException e) {
			System.out.println(e);
		}

	}

	private ObservableList<DisciplinaBEAN> getDataTableViewDisciplina() throws SQLException {
		DisciplinaModel disciplinaModel = new DisciplinaModel();
		ProfessorBEAN professorBEAN = new ProfessorBEAN();
		professorBEAN.setMatricula(Long.parseLong(System.getProperty("matricula")));
		return FXCollections.observableArrayList(disciplinaModel.getDataTableViewDisciplina(professorBEAN));
	}
}

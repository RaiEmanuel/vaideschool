package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.Main;
import bean.DataTableViewHomeAlunoBEAN;
import bean.DataTableViewHomeProfessorBEAN;
import bean.ProfessorBEAN;
import javafx.beans.property.SimpleLongProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.AlunoModel;
import model.ProfessorModel;

public class HomeProfessorController implements Initializable{
	@FXML private TableView<DataTableViewHomeProfessorBEAN> tabela;
	@FXML private TableColumn<DataTableViewHomeProfessorBEAN, String> disciplina;
	@FXML private TableColumn<DataTableViewHomeProfessorBEAN, String> local;
	@FXML private TableColumn<DataTableViewHomeProfessorBEAN, String> horario;
	@FXML private TableColumn<DataTableViewHomeProfessorBEAN, Long> idTurma;
	@FXML private Button btnEditarExcluir, btnVisualizarTurma, btnCriarDisciplina, btnCriarTurma;

	private Main view;
	
	private ObservableList<DataTableViewHomeProfessorBEAN> getDataTableViewHomeProfessor() throws SQLException {
		ProfessorModel professorModel = new ProfessorModel();
		ProfessorBEAN professorBEAN = new ProfessorBEAN();
		professorBEAN.setMatricula(Long.parseLong(System.getProperty("matricula")));
        return FXCollections.observableArrayList(professorModel.getDataTableViewHomeProfessor(professorBEAN));
    }
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		disciplina.setCellValueFactory(
                new PropertyValueFactory<>("disciplina"));
        local.setCellValueFactory(
                new PropertyValueFactory<>("local"));
        horario.setCellValueFactory(
                new PropertyValueFactory<>("horario"));
        idTurma.setCellValueFactory(
        		new PropertyValueFactory<>("idTurma"));
        
       try {
			tabela.setItems(getDataTableViewHomeProfessor());
		} catch (SQLException e) {
			System.out.println(e);
		}
     
	}
	
	@FXML
	protected void cadastroTurma(ActionEvent event) throws IOException {
		view = new Main();
		view.viewCadastroTurma();
	}
	
	@FXML
	protected void cadastroDisciplina(ActionEvent event) {
		view = new Main();
		view.viewCadastroDisciplina();
	}
	
	@FXML
	protected void vizualizarTurma(ActionEvent event) throws IOException {
		DataTableViewHomeProfessorBEAN dataTableViewHomeProfessorBEAN = tabela.getSelectionModel().getSelectedItem();
		if(dataTableViewHomeProfessorBEAN != null) {
			/*** Variavel de sistema criada para poder passar entre camadas na chamada de nova tela ***/
			/*** DELETAR VARIAVEL AO SAIR DA TELA ***/
			System.setProperty("idTurma", String.valueOf(dataTableViewHomeProfessorBEAN.getIdTurma()));
			view = new Main();
			view.viewVisualizarTurmaProfessor();
		}else {
			JOptionPane.showMessageDialog(null, "Selecione uma turma", "Aten��o", JOptionPane.WARNING_MESSAGE);
		}
		
	}
	
	@FXML
	protected void sair(ActionEvent event) {
		view = new Main();
		view.viewLogin();
		
	}
	
	
	@FXML 
	protected void editarExcluirDisciplina() throws IOException {
		view = new Main();
		view.viewEditarExcluirDisciplina();
	}
	/* exclusivo do aluno
	@FXML
	protected void entrarTurma() throws IOException {
		 view = new Main();
		 view.viewEntrarTurma();
	}
	*/ 
	
	
	
}

package controller;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import application.Main;
import bean.AlunoBEAN;
import bean.ProfessorBEAN;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import model.CadastroModel;
import utility.Criptografador;

public class CadastroAlunoProfessorController {
	@FXML private Button btnCadastrar, btnVoltar;
	@FXML private TextField nome, rua, bairro, numero, rg;
	@FXML private PasswordField senha;
	@FXML private ToggleGroup nivelAcesso;
	@FXML private RadioButton radioAluno, radioProfessor;
	private Main view;
	
	@FXML protected void cadastrar() throws UnsupportedEncodingException, NoSuchAlgorithmException, SQLException {
		CadastroModel cadastroModel = new CadastroModel();
			
		if(nivelAcesso.getSelectedToggle().equals(radioAluno)) {
			AlunoBEAN alunoBEAN = new AlunoBEAN();
			alunoBEAN.setNome(nome.getText());
			alunoBEAN.setRua(rua.getText());
			alunoBEAN.setBairro(bairro.getText());
			try {//trim
				if(numero.getText().length() == 0) {
					alunoBEAN.setNumero((short) 0);
				}else{
					alunoBEAN.setNumero(Short.parseShort(numero.getText()));
				}
			}catch(NumberFormatException e){
				JOptionPane.showMessageDialog(null, "N�mero da resid�ncia � obrigatoriamente um n�mero", "Aten��o",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			alunoBEAN.setRg(rg.getText());
			alunoBEAN.setNivelAcesso("aluno");
			alunoBEAN.setSenha(Criptografador.criptografar(senha.getText()));
			cadastroModel.cadastrar(alunoBEAN);
		}else if(nivelAcesso.getSelectedToggle().equals(radioProfessor)) {
			ProfessorBEAN professorBEAN = new ProfessorBEAN();
			professorBEAN.setNome(nome.getText());
			professorBEAN.setRua(rua.getText());
			professorBEAN.setBairro(bairro.getText());
			try {//trim
				if(numero.getText().length() == 0) {
					professorBEAN.setNumero((short) 0);
				}else{
					professorBEAN.setNumero(Short.parseShort(numero.getText()));
				}
			}catch(NumberFormatException e){
				JOptionPane.showMessageDialog(null, "N�mero da resid�ncia � obrigatoriamente um n�mero", "Aten��o",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			professorBEAN.setNivelAcesso("professor");
			professorBEAN.setSenha(Criptografador.criptografar(senha.getText()));
			cadastroModel.cadastrar(professorBEAN);
		}
		
	}
		
	@FXML protected void alteraRadio() {
		if(nivelAcesso.getSelectedToggle().equals(radioAluno)) {
			rg.setDisable(false);
		}else if(nivelAcesso.getSelectedToggle().equals(radioProfessor)) {
			rg.setDisable(true);
		}
	}
	
	@FXML protected void voltar() {
		view = new Main();
		view.viewLogin();
	}
	
	
	
	
	
	
}

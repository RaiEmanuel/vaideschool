package controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import application.Main;
import bean.AlunoBEAN;
import bean.PessoaBEAN;
import bean.ProfessorBEAN;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import model.LoginModel;
import utility.Criptografador;

public class LoginController {
	@FXML
	private Button btnLogin;
	@FXML
	private TextField matricula;
	@FXML
	private PasswordField senha;
	@FXML
	private ToggleGroup nivelAcesso;
	@FXML
	private RadioButton radioAluno, radioProfessor;

	private Main view;


	@FXML
	protected /* PessoaBEAN */void autenticar(ActionEvent event)
			throws NoSuchAlgorithmException, SQLException, IOException {

		LoginModel loginModel;
		loginModel = new LoginModel();
	
		
		PessoaBEAN pessoaBEAN = null;

		if (nivelAcesso.getSelectedToggle().equals(radioAluno)) {
			AlunoBEAN alunoBEAN = new AlunoBEAN();
			alunoBEAN.setSenha(Criptografador.criptografar(senha.getText()));// pegando senha criptografada com sha-256 em hex
			try {
				alunoBEAN.setMatricula(Long.parseLong(matricula.getText()));
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Matr�cula � obrigatoriamente somente n�meros", "Aten��o",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			alunoBEAN.setNivelAcesso("aluno");
			pessoaBEAN = loginModel.autenticar(alunoBEAN);			
		} else if (nivelAcesso.getSelectedToggle().equals(radioProfessor)) {
			ProfessorBEAN professorBEAN = new ProfessorBEAN();
			professorBEAN.setSenha(Criptografador.criptografar(senha.getText()));// pegando senha criptografada com sha-256 em hex
			try {
				professorBEAN.setMatricula(Long.parseLong(matricula.getText()));
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Matr�cula � obrigatoriamente somente n�meros", "Aten��o",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			professorBEAN.setNivelAcesso("professor");
			pessoaBEAN = loginModel.autenticar(professorBEAN);
		}
		if(pessoaBEAN != null) {
			view = new Main();
			view.viewHomeAluno();
		}else {
			JOptionPane.showMessageDialog(null, "Login ou senha incorretos", "Login", JOptionPane.WARNING_MESSAGE);
		}
	}

	@FXML
	protected void cadastrar() throws IOException {
		view = new Main();
		view.viewCadastro();
	}
}

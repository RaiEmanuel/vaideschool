package controller;

import javax.swing.JOptionPane;

import application.Main;
import bean.DisciplinaBEAN;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import model.DisciplinaModel;

public class CadastroDisciplinaController {
	@FXML private TextField disciplina, cargaHoraria, horaAula;
	@FXML private Button btnCadastrar;
	private final byte CARGA_HORARIA_DEFAULT = 60, HORA_AULA_DEFAULT = 60;
	private Main view; 

	@FXML
	protected void cadastrar(ActionEvent event) {
		DisciplinaBEAN disciplinaBEAN = new DisciplinaBEAN();

		String disciplinaAux = disciplina.getText();
		disciplinaAux = disciplinaAux.trim();
		if (disciplinaAux.length() >= 3) {
			disciplinaBEAN.setNome(disciplinaAux);
		} else {
			JOptionPane.showMessageDialog(null, "A disciplina deve ter pelo menos 3 caracteres", "Aten��o",
					JOptionPane.WARNING_MESSAGE);
			disciplina.setText(disciplinaAux);
			return;
		}
		try {
			disciplinaBEAN.setCarga_horaria(Byte.parseByte(cargaHoraria.getText()));

		} catch (NumberFormatException e) {
			disciplinaBEAN.setCarga_horaria(CARGA_HORARIA_DEFAULT);

		}
		try {
			disciplinaBEAN.setHora_aula(Byte.parseByte(horaAula.getText()));
		} catch (NumberFormatException e) {
			disciplinaBEAN.setHora_aula(HORA_AULA_DEFAULT);
		}
		DisciplinaModel disciplinaModel = new DisciplinaModel();
		if(disciplinaBEAN.getCarga_horaria() >= disciplinaBEAN.getHora_aula()) {
			
			if(disciplinaModel.create(disciplinaBEAN) == 1) {
				JOptionPane.showMessageDialog(null, "Sucesso ao criar disciplina");
			}else {
				JOptionPane.showMessageDialog(null, "Erro ao criar disciplina");
			}
			
			
		}else {
			JOptionPane.showMessageDialog(null, "A carga hor�ria deve ser maior que igual a hora aula");
			return;
		}
		
	}
	
	@FXML
	protected void voltar(ActionEvent event) {
		view = new Main();
		view.viewHomeProfessor();
	}
	
}

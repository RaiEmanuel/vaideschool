package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

public class visualizarTurmaAlunoController implements Initializable{
	@FXML
	private TextField p1, p2, p3, p4, mediaFinal, faltas, aprovado, status;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
	}
	
}

package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import application.Main;
import bean.DataTableViewEntrarTurmaBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

public class entrarTurmaController implements Initializable {
	@FXML
	private TableView<DataTableViewEntrarTurmaBEAN> tabela;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> disciplina;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> local;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> horario;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> professor;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, Long> idTurma;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, Boolean> select;
	@FXML
	private Button btnVoltar;
	Main view;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		select.setCellValueFactory(new PropertyValueFactory<>("select"));
		disciplina.setCellValueFactory(new PropertyValueFactory<>("disciplina"));
		local.setCellValueFactory(new PropertyValueFactory<>("local"));
		horario.setCellValueFactory(new PropertyValueFactory<>("horario"));
		professor.setCellValueFactory(new PropertyValueFactory<>("professor"));
		idTurma.setCellValueFactory(new PropertyValueFactory<>("idTurma"));
		select.setCellFactory(CheckBoxTableCell.forTableColumn(select));
		
		try {
			tabela.setItems(getDataTableViewEntrarTurma());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	protected void voltar() throws IOException {
		view = new Main();
		view.viewHomeAluno();
	}
	
	@FXML protected void cadastrar(ActionEvent e) {
		System.out.println(tabela.getItems().get(0).getSelect().isSelected());
		
	}
	
	private ObservableList<DataTableViewEntrarTurmaBEAN> getDataTableViewEntrarTurma() throws SQLException {
		List<DataTableViewEntrarTurmaBEAN> lista = new ArrayList<DataTableViewEntrarTurmaBEAN>();
		lista.add(new DataTableViewEntrarTurmaBEAN());
		return FXCollections.observableArrayList(lista);
	}
	public class CheckBoxCellFactory implements Callback {
	    public TableCell call(Object param) {
	        CheckBoxTableCell<DataTableViewEntrarTurmaBEAN,Boolean> checkBoxCell = new CheckBoxTableCell();
	        return checkBoxCell;
	    }
	}
}

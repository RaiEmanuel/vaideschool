package controller;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.color.PDJPXColorSpace;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfNumber;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPage;
import com.itextpdf.text.pdf.PdfWriter;

import application.Main;
import bean.AlunoBEAN;
import bean.DataTableViewHomeAlunoBEAN;
import bean.HistoricoBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.AlunoModel;
import utility.Criptografador;

public class HomeAlunoController implements Initializable {
	@FXML
	private TableView<DataTableViewHomeAlunoBEAN> tabela;
	@FXML
	private TableColumn<DataTableViewHomeAlunoBEAN, String> idTurma;
	@FXML
	private TableColumn<DataTableViewHomeAlunoBEAN, String> disciplina;
	@FXML
	private TableColumn<DataTableViewHomeAlunoBEAN, String> local;
	@FXML
	private TableColumn<DataTableViewHomeAlunoBEAN, String> horario;
	@FXML
	private TableColumn<DataTableViewHomeAlunoBEAN, String> professor;
	@FXML
	private Label saudacao;
	@FXML
	private Button btnGerarHistoricoPDF, btnSair, btnVisualizarTurma;
	private Main view;

	private ObservableList<DataTableViewHomeAlunoBEAN> getDataTableViewHomeAluno() throws SQLException {
		AlunoModel alunoModel = new AlunoModel();
		DataTableViewHomeAlunoBEAN dataTableViewHomeAluno = new DataTableViewHomeAlunoBEAN();
		return FXCollections.observableArrayList(alunoModel.getDataTableViewHomeAluno(dataTableViewHomeAluno));
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		/* SETANDO ICONES */
		saudacao.setText("Ol�, " + System.getProperty("nome"));
		/* SETANDO ICONES */
		idTurma.setCellValueFactory(new PropertyValueFactory<>("idTurma"));
		disciplina.setCellValueFactory(new PropertyValueFactory<>("disciplina"));
		local.setCellValueFactory(new PropertyValueFactory<>("local"));
		horario.setCellValueFactory(new PropertyValueFactory<>("horario"));
		professor.setCellValueFactory(new PropertyValueFactory<>("professor"));
		try {
			tabela.setItems(getDataTableViewHomeAluno());
		} catch (SQLException e) {
			System.out.println(e);
		}

	}

	@FXML
	protected void entrarTurma(ActionEvent event) throws IOException {
		view = new Main();
		view.viewEntrarTurma();
	}

	@FXML
	protected void sair(ActionEvent event) {
		System.clearProperty("matricula");
		System.clearProperty("nome");
		System.clearProperty("rua");
		System.clearProperty("bairro");
		System.clearProperty("numero");
		view = new Main();
		view.viewLogin();
	}

	@FXML
	protected void gerarHistoricoPDF(ActionEvent event) throws InvalidPasswordException, IOException, SQLException, NoSuchAlgorithmException {
		/*** GERANDO NOME DO ARQUIVO ***/
		Calendar calendar = Calendar.getInstance();
		StringBuilder nameFile = new StringBuilder();
		DecimalFormat df = new DecimalFormat("00");
		nameFile.append("src/pdf/");
		nameFile.append(df.format(calendar.get(Calendar.DAY_OF_MONTH)) + "_");
		nameFile.append(df.format((calendar.get(Calendar.MONTH) + 1)) + "_");// +1 porque m�s come�a no 0 (JAN)
		nameFile.append(df.format(calendar.get(Calendar.YEAR)) + "_");
		nameFile.append(df.format(calendar.get(Calendar.HOUR)) + "_");
		nameFile.append(df.format(calendar.get(Calendar.MINUTE)) + "_");
		nameFile.append(df.format(calendar.get(Calendar.SECOND)));
		nameFile.append("_Hist�rico_PDF_" + System.getProperty("nome") + ".pdf");
		/*** FIM GERANDO NOME DO ARQUIVO ***/
		final String LOGO_UFERSA_URL = "src/icons/ufersa.png";

		Document document = new Document();

		try {
			PdfWriter.getInstance(document, new FileOutputStream(nameFile.toString()));
			document.setPageSize(PageSize.A4.rotate());
			document.open();
			Image image = Image.getInstance(LOGO_UFERSA_URL);
			image.setAlignment(Element.ALIGN_CENTER);
			image.setSpacingAfter(15.0f);
			document.add(image);
			PdfPTable table = new PdfPTable(10); // 3 columns.
			table.setTotalWidth(100f);
			table.setWidths(new float[] {0.07f,0.07f,0.07f,0.07f,0.07f,0.07f,0.07f,0.2275f,0.2275f,0.11f});
			//professor.nome, disciplina.nome, p1, p2, p3, p4, media_final, faltas, aprovado, turma.status
			PdfPCell nomeAluno = new PdfPCell(new Paragraph("Aluno: "+System.getProperty("nome")));
			nomeAluno.setVerticalAlignment(Element.ALIGN_CENTER);nomeAluno.setHorizontalAlignment(Element.ALIGN_CENTER);
			nomeAluno.setColspan(7);
			String time_in_millis = String.valueOf(calendar.getTimeInMillis());//tempo para criptografar
			PdfPCell codigo = new PdfPCell(new Paragraph("C�digo verifica��o de autenticidade: "+Criptografador.criptografar(time_in_millis)));
			codigo.setVerticalAlignment(Element.ALIGN_CENTER);codigo.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			codigo.setColspan(3);
			PdfPCell cell1 = new PdfPCell(new Paragraph("P1"));
			cell1.setVerticalAlignment(Element.ALIGN_CENTER);cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell2 = new PdfPCell(new Paragraph("P2"));
			cell2.setVerticalAlignment(Element.ALIGN_CENTER);cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell3 = new PdfPCell(new Paragraph("P3"));
			cell3.setVerticalAlignment(Element.ALIGN_CENTER);cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell4 = new PdfPCell(new Paragraph("P4"));
			cell4.setVerticalAlignment(Element.ALIGN_CENTER);cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell5 = new PdfPCell(new Paragraph("M�dia"));
			cell5.setVerticalAlignment(Element.ALIGN_CENTER);cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell6 = new PdfPCell(new Paragraph("Faltas"));
			cell6.setVerticalAlignment(Element.ALIGN_CENTER);cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell7 = new PdfPCell(new Paragraph("Status"));
			cell7.setVerticalAlignment(Element.ALIGN_CENTER);cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell8 = new PdfPCell(new Paragraph("Professor"));
			cell8.setVerticalAlignment(Element.ALIGN_CENTER);cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell9 = new PdfPCell(new Paragraph("Disciplina"));
			cell9.setVerticalAlignment(Element.ALIGN_CENTER);cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cell10 = new PdfPCell(new Paragraph("Aprovado"));
			cell9.setVerticalAlignment(Element.ALIGN_CENTER);cell10.setHorizontalAlignment(Element.ALIGN_CENTER);

			table.addCell(nomeAluno);
			table.addCell(codigo);
			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);
			table.addCell(cell9);
			table.addCell(cell10);
			
			
			for(HistoricoBEAN historicoBEAN : getDataHistorico()) {
				//Paragraph pBEAN = new Paragraph(String.valueOf(historicoBEAN.getP1()));
				cell1 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.getP1())));
				cell1.setVerticalAlignment(Element.ALIGN_CENTER);cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell2 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.getP2())));
				cell2.setVerticalAlignment(Element.ALIGN_CENTER);cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell3 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.getP3())));
				cell3.setVerticalAlignment(Element.ALIGN_CENTER);cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.getP4())));
				cell4.setVerticalAlignment(Element.ALIGN_CENTER);cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.getMedia())));
				cell5.setVerticalAlignment(Element.ALIGN_CENTER);cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.getFaltas())));
				cell6.setVerticalAlignment(Element.ALIGN_CENTER);cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.getStatus())));
				cell7.setVerticalAlignment(Element.ALIGN_CENTER);cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8 = new PdfPCell(new Paragraph(historicoBEAN.getNomeProfessor()));
				cell8.setVerticalAlignment(Element.ALIGN_CENTER);cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9 = new PdfPCell(new Paragraph(historicoBEAN.getDisciplina()));
				cell9.setVerticalAlignment(Element.ALIGN_CENTER);cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10 = new PdfPCell(new Paragraph(String.valueOf(historicoBEAN.isAprovado())));
				cell10.setVerticalAlignment(Element.ALIGN_CENTER);cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				
				table.addCell(cell1);
				table.addCell(cell2);
				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
			}
			
			if(Desktop.isDesktopSupported()) {
				Desktop.getDesktop().open(new File(nameFile.toString()));
			}else {
				JOptionPane.showMessageDialog(null, "N�o � poss�vel abrir documento PDF", "Erro no PDF", JOptionPane.WARNING_MESSAGE);
			}

			document.add(table);

			document.close();
		} catch (DocumentException e) {

			e.printStackTrace();
		}

	}

	protected List<HistoricoBEAN> getDataHistorico() throws SQLException{
		AlunoModel alunoModel = new AlunoModel();
		AlunoBEAN alunoBEAN = new AlunoBEAN();
		alunoBEAN.setMatricula(Long.parseLong(System.getProperty("matricula")));
		return alunoModel.getDataHistorico(alunoBEAN);
	}
}

package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import application.Main;
import bean.DataTableViewHomeAlunoBEAN;
import javafx.beans.property.SimpleLongProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.AlunoModel;

public class HomeAlunoController implements Initializable{
	@FXML private TableView<DataTableViewHomeAlunoBEAN> tabela;
	@FXML private TableColumn<DataTableViewHomeAlunoBEAN, String> disciplina;
	@FXML private TableColumn<DataTableViewHomeAlunoBEAN, String> local;
	@FXML private TableColumn<DataTableViewHomeAlunoBEAN, String> horario;
	@FXML private TableColumn<DataTableViewHomeAlunoBEAN, String> professor;
	@FXML private Label saudacao;
	@FXML private Button btnHistorico, btnSair;
	private Main view;
	
	private ObservableList<DataTableViewHomeAlunoBEAN> getDataTableViewHomeAluno() throws SQLException {
		AlunoModel alunoModel = new AlunoModel();
		DataTableViewHomeAlunoBEAN dataTableViewHomeAluno = new DataTableViewHomeAlunoBEAN();
		dataTableViewHomeAluno.setIdAlunoLogado(new SimpleLongProperty(11));
        return FXCollections.observableArrayList(alunoModel.getDataTableViewHomeAluno(dataTableViewHomeAluno));
    }
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		/* SETANDO ICONES */
		saudacao.setText("Ol�, "+System.getProperty("nome"));
		/* SETANDO ICONES */
		disciplina.setCellValueFactory(
                new PropertyValueFactory<>("disciplina"));
        local.setCellValueFactory(
                new PropertyValueFactory<>("local"));
        horario.setCellValueFactory(
                new PropertyValueFactory<>("horario"));
        professor.setCellValueFactory(
                new PropertyValueFactory<>("professor"));
       try {
			tabela.setItems(getDataTableViewHomeAluno());
		} catch (SQLException e) {
			System.out.println(e);
		}
     
	}
	
	@FXML
	protected void entrarTurma(ActionEvent event) throws IOException {
		 view = new Main();
		 view.viewEntrarTurma();
	}
	
	@FXML protected void sair(ActionEvent event) {
		System.clearProperty("matricula");
		System.clearProperty("nome");
		System.clearProperty("rua");
		System.clearProperty("bairro");
		System.clearProperty("numero");
		view = new Main();
		view.viewLogin();
	}
	
	
	
}

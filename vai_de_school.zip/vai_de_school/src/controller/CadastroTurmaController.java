package controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.Main;
import bean.HorarioBEAN;
import bean.TurmaBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.TurmaModel;

public class CadastroTurmaController implements Initializable{
	
	@FXML private TextField localAula, horario;
	@FXML private ComboBox<String> disciplina;
	@FXML private Button btnCadastrar, btnVoltar;
	private Main view;
		
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//professores
		List<String> professores = getProfessores();
		ObservableList<String> lista = FXCollections.observableArrayList(professores);
		//professor.setItems(lista);
		//disciplinas
		List<String> disciplinas = getDisciplinas();
		ObservableList<String> lista2 = FXCollections.observableArrayList(disciplinas);
		disciplina.setItems(lista2);
	}
	
	@FXML
	protected void cadastrar(ActionEvent event) {
		TurmaModel turmaModel = new TurmaModel();
		//long matriculaProfessor = turmaModel.getMatriculaProfessorByName(professor.getSelectionModel().getSelectedItem());
		long idDisciplina = turmaModel.getidDisciplinaByName(disciplina.getSelectionModel().getSelectedItem());
		//JOptionPane.showMessageDialog(null, matriculaProfessor+" : "+idDisciplina);
		
		TurmaBEAN turmaBEAN = new TurmaBEAN();
		turmaBEAN.setIdDisciplina(idDisciplina);
		/* PEGAR ID DO PROFESSOR LOGADO E POR AQUI */
		long matricula = Long.parseLong(System.getProperty("matricula"));
		turmaBEAN.setMatriculaProfessor(matricula);
		turmaBEAN.setLocal(localAula.getText());
		turmaBEAN.setStatus('A');
		
		if(turmaModel.create(turmaBEAN) == 1) {/* Significa que cadastro a turma no banco. Falta cadastrar o horario associado � turma */
			//Generics_T_K_BEAN<HorarioBEAN, TurmaBEAN> generics_T_K_BEAN = new Generics_T_K_BEAN<>();
			/* Prepara��o do horario */
			HorarioBEAN horarioBEAN = new HorarioBEAN();
			horarioBEAN.setHorario(horario.getText());
			long idTurma = turmaModel.getIdTurmaLast();
			horarioBEAN.setIdTurma(idTurma);
			if(turmaModel.cadastrarHorario(horarioBEAN) == 1) {
				JOptionPane.showMessageDialog(null, "Sucesso ao criar turma");
			}else {
				JOptionPane.showMessageDialog(null, "Erro ao associar o hor�rio � turma");
				//System.out.println("turma cadastrada mas erro na criacao do horario");
				/***   	DELETAR ULTIMA TURMA CADASTRADA       ***/
			}
			
			//List<HorarioBEAN> listHorarioBEAN = new ArrayList<>();
			//listHorarioBEAN.add(horarioBEAN);
			/* Prepara��o da turma */
			//generics_T_K_BEAN.setListaK(listaK);
		}else {
			JOptionPane.showMessageDialog(null, "Erro ao criar a turma");
		}
		
	}
	
	@FXML
	protected void voltar(ActionEvent event) {
		System.clearProperty("idTurma");/*** LIMPAR VARIAVEL AO SAIR DA JANELA ***/
		view = new Main();
		view.viewHomeProfessor();
	}
	
	public List<String> getProfessores() {
		TurmaModel turmaModel = new TurmaModel();
		return turmaModel.getProfessores();
	}

	public List<String> getDisciplinas() {
		TurmaModel turmaModel = new TurmaModel();
		return turmaModel.getDisciplinas();
	}
}

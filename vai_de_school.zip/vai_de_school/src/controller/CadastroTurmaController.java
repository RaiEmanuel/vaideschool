package controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import bean.ProfessorBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.TurmaModel;

public class CadastroTurmaController implements Initializable{
	
	@FXML private TextField localAula;
	@FXML private ComboBox<String> professor, disciplina;
	@FXML private Button btnCadastrar;
		
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//professores
		List<String> professores = getProfessores();
		ObservableList<String> lista = FXCollections.observableArrayList(professores);
		professor.setItems(lista);
		//disciplinas
		List<String> disciplinas = getDisciplinas();
		ObservableList<String> lista2 = FXCollections.observableArrayList(disciplinas);
		disciplina.setItems(lista2);
	}
	
	@FXML
	protected void cadastrar(ActionEvent event) {
		TurmaModel turmaModel = new TurmaModel();
		turmaModel.cadastrar();
	}
	
	public List<String> getProfessores() {
		TurmaModel turmaModel = new TurmaModel();
		return turmaModel.getProfessores();
	}

	public List<String> getDisciplinas() {
		TurmaModel turmaModel = new TurmaModel();
		return turmaModel.getDisciplinas();
	}
}

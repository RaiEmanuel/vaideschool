package controller;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import application.Main;
import bean.TurmaBEAN;
import bean.Turma_has_AlunoBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.AlunoModel;

public class visualizarTurmaProfessorController implements Initializable {
	@FXML
	private TableView<Turma_has_AlunoBEAN> tabela;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, Long> matriculaAluno;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, String> nomeAluno;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, Double> p1, p2, p3, p4;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, Byte> faltas;
	@FXML
	private Button btnVoltar, btnFinalizarTurma;
	@FXML
	private Label idTurma, disciplina;
	@FXML
	private Main view;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		idTurma.setText("idTurma = "+System.getProperty("idTurma"));
		matriculaAluno.setCellValueFactory(new PropertyValueFactory<>("matriculaAluno"));
		nomeAluno.setCellValueFactory(new PropertyValueFactory<>("nomeAluno"));
		p1.setCellValueFactory(new PropertyValueFactory<>("p1"));
		p2.setCellValueFactory(new PropertyValueFactory<>("p2"));
		p3.setCellValueFactory(new PropertyValueFactory<>("p3"));
		p4.setCellValueFactory(new PropertyValueFactory<>("p4"));
		faltas.setCellValueFactory(new PropertyValueFactory<>("faltas"));
		try {
			/***   USAR ESSE MODELO QUANDO RECEBER PARAMETRO DO SYSTEM/SINGLETON PARA FICAR MAIS SEMANTICO    ***/
			TurmaBEAN turmaBEAN = new TurmaBEAN();
			turmaBEAN.setIdTurma(Long.parseLong(System.getProperty("idTurma")));
			tabela.setItems(getDataTableVisualizarProfessor(turmaBEAN));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	private ObservableList<Turma_has_AlunoBEAN> getDataTableVisualizarProfessor(TurmaBEAN turmaBEAN) throws SQLException {
		AlunoModel alunoModel = new AlunoModel();
		return FXCollections.observableArrayList(alunoModel.getDataTableViewVisualizarTurmaProfessor(turmaBEAN));
	}
	
	@FXML
	protected void voltar(ActionEvent event) {
		view = new Main();
		view.viewHomeProfessor();
	}

}

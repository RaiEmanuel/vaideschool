package controller;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import application.Main;
import bean.TurmaBEAN;
import bean.Turma_has_AlunoBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.ByteStringConverter;
import javafx.util.converter.DoubleStringConverter;
import model.AlunoModel;
import model.ProfessorModel;
import model.TurmaModel;

public class visualizarTurmaProfessorController implements Initializable {
	@FXML
	private TableView<Turma_has_AlunoBEAN> tabela;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, Long> matriculaAluno;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, String> nomeAluno;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, Double> p1, p2, p3, p4;
	@FXML
	private TableColumn<Turma_has_AlunoBEAN, Byte> faltas;
	@FXML
	private Button btnVoltar, btnFinalizarTurma;
	@FXML
	private Label idTurma, disciplina;
	@FXML
	private Main view;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		idTurma.setText("idTurma = "+System.getProperty("idTurma"));
		//--------------
		matriculaAluno.setCellValueFactory(new PropertyValueFactory<Turma_has_AlunoBEAN, Long>("matriculaAluno"));
		nomeAluno.setCellValueFactory(new PropertyValueFactory<Turma_has_AlunoBEAN, String>("nomeAluno"));
		p1.setCellValueFactory(new PropertyValueFactory<Turma_has_AlunoBEAN, Double>("p1"));
		p1.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
		p2.setCellValueFactory(new PropertyValueFactory<Turma_has_AlunoBEAN, Double>("p2"));
		p2.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
		p3.setCellValueFactory(new PropertyValueFactory<Turma_has_AlunoBEAN, Double>("p3"));
		p3.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
		p4.setCellValueFactory(new PropertyValueFactory<Turma_has_AlunoBEAN, Double>("p4"));
		p4.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
		faltas.setCellValueFactory(new PropertyValueFactory<Turma_has_AlunoBEAN, Byte>("faltas"));
		faltas.setCellFactory(TextFieldTableCell.forTableColumn(new ByteStringConverter()));
		try {
			/***   USAR ESSE MODELO QUANDO RECEBER PARAMETRO DO SYSTEM/SINGLETON PARA FICAR MAIS SEMANTICO    ***/
			TurmaBEAN turmaBEAN = new TurmaBEAN();
			turmaBEAN.setIdTurma(Long.parseLong(System.getProperty("idTurma")));
			tabela.setItems(getDataTableVisualizarProfessor(turmaBEAN));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		 
	}

	private ObservableList<Turma_has_AlunoBEAN> getDataTableVisualizarProfessor(TurmaBEAN turmaBEAN) throws SQLException {
		AlunoModel alunoModel = new AlunoModel();
		return FXCollections.observableArrayList(alunoModel.getDataTableViewVisualizarTurmaProfessor(turmaBEAN));
	}
	
	@FXML
	protected void voltar(ActionEvent event) {
		view = new Main();
		view.viewHomeProfessor();
	}

	@FXML
	protected void finalizarTurma() throws SQLException {
		ProfessorModel professorModel = new ProfessorModel();
		TurmaModel turmaModel = new TurmaModel();
		for(Turma_has_AlunoBEAN turma_has_alunoBEAN : tabela.getSelectionModel().getTableView().getItems()) {
			System.out.println(turma_has_alunoBEAN.toString());
			/*** colocando id da turma no bean para poder atualizar a tabela turma_has_aluno ***/
			long idTurma = Long.parseLong(System.getProperty("idTurma"));
			turma_has_alunoBEAN.setIdTurma(idTurma);
			int sucessoSetarNotas = professorModel.setNotas(turma_has_alunoBEAN);
			int sucessoSetarStatus = turmaModel.setStatus(turma_has_alunoBEAN);
			if(sucessoSetarNotas * sucessoSetarStatus == 1) {
				JOptionPane.showMessageDialog(null, "Sucesso ao finalizar a turma");
			}else {
				/*** CALLBACK NO BANCO  
				 * int sucessoSetarNotas = professorModel.setNotas(turma_has_alunoBEAN);
				 * int sucessoSetarStatus = turmaModel.setStatus(turma_has_alunoBEAN);
				 * 
				 * ***/
				JOptionPane.showMessageDialog(null, "Erro ao finalizar a turma");
			}
				/*JOptionPane.showMessageDialog(null, "Sucesso ao atualizar notas: "+sucessoSetarNotas);
				JOptionPane.showMessageDialog(null, "Sucesso ao atualizar notas: "+sucessoSetarStatus);*/
			
		}
		/*** Codigo de finalizar disciplina aqui. Abaixo declarar model professor e chamar o metodo respectivo para chamar o dao ... ***/
		//professorModel.setNotas(turma_has_alunoBEAN);
	}
	
	@FXML
	protected void commitP1(CellEditEvent<Turma_has_AlunoBEAN, Double> event) {
		event.getTableView().getItems().get(event.getTablePosition().getRow()).setP1(event.getNewValue());
	}
	
	@FXML
	protected void commitP2(CellEditEvent<Turma_has_AlunoBEAN, Double> event) {
		event.getTableView().getItems().get(event.getTablePosition().getRow()).setP2(event.getNewValue());
	}
	
	@FXML
	protected void commitP3(CellEditEvent<Turma_has_AlunoBEAN, Double> event) {
		event.getTableView().getItems().get(event.getTablePosition().getRow()).setP3(event.getNewValue());
	}
	
	@FXML
	protected void commitP4(CellEditEvent<Turma_has_AlunoBEAN, Double> event) {
		event.getTableView().getItems().get(event.getTablePosition().getRow()).setP4(event.getNewValue());
	}
	
	@FXML
	protected void commitFaltas(CellEditEvent<Turma_has_AlunoBEAN, Byte> event) {
		event.getTableView().getItems().get(event.getTablePosition().getRow()).setFaltas(event.getNewValue());
	}
}

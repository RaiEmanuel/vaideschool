package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import application.Main;
import bean.DataTableViewEntrarTurmaBEAN;
import bean.Turma_has_AlunoBEAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.AlunoModel;

public class EntrarTurmaController implements Initializable {
	@FXML
	private TableView<DataTableViewEntrarTurmaBEAN> tabela;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> disciplina;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> local;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> horario;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, String> professor;
	@FXML
	private TableColumn<DataTableViewEntrarTurmaBEAN, Long> idTurma;
	@FXML
	private Button btnVoltar;
	Main view;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		disciplina.setCellValueFactory(new PropertyValueFactory<>("disciplina"));
		local.setCellValueFactory(new PropertyValueFactory<>("local"));
		horario.setCellValueFactory(new PropertyValueFactory<>("horario"));
		professor.setCellValueFactory(new PropertyValueFactory<>("professor"));
		idTurma.setCellValueFactory(new PropertyValueFactory<>("idTurma"));
		try {
			tabela.setItems(getDataTableViewEntrarTurma());
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	@FXML
	protected void voltar(ActionEvent e) throws IOException {
		view = new Main();
		view.viewHomeAluno();
	}
	
	@FXML protected void cadastrar(ActionEvent e) throws SQLException {
		//System.out.println();
		AlunoModel alunoModel = new AlunoModel();
		long idTurma = tabela.getSelectionModel().getSelectedItem().getIdTurma();//pega dados da tabela
		Turma_has_AlunoBEAN turma_has_AlunoBEAN = new Turma_has_AlunoBEAN();
		turma_has_AlunoBEAN.setIdTurma(idTurma);
		turma_has_AlunoBEAN.setIdAluno(Long.parseLong(System.getProperty("matricula")));//aluno logado
		turma_has_AlunoBEAN.setP1(0);
		turma_has_AlunoBEAN.setP2(0);
		turma_has_AlunoBEAN.setP3(0);
		turma_has_AlunoBEAN.setP4(0);
		turma_has_AlunoBEAN.setFaltas((byte) 0);
		turma_has_AlunoBEAN.setAprovado(false);
		turma_has_AlunoBEAN.setMedial_final(0);	
		alunoModel.entrarTurma(turma_has_AlunoBEAN);
		initialize(null, null);
	}
	
	private ObservableList<DataTableViewEntrarTurmaBEAN> getDataTableViewEntrarTurma() throws SQLException {
		AlunoModel alunoModel = new AlunoModel();
		return FXCollections.observableArrayList(alunoModel.getDataTableViewEntrarTurma());
	}
}

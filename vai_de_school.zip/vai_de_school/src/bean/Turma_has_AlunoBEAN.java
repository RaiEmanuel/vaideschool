package bean;

public class Turma_has_AlunoBEAN{
	private long idTurma = 0, matriculaAluno = 0;
	private double p1 = 0, p2 = 0, p3 = 0, p4 = 0, medial_final = 0;
	private byte faltas = 0;
	private boolean aprovado = false;
	private String nomeAluno = "";
	
	public String getNomeAluno() {
		return nomeAluno;
	}
	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		this.idTurma = idTurma;
	}
	
	public long getMatriculaAluno() {
		return matriculaAluno;
	}
	public void setMatriculaAluno(long matriculaAluno) {
		this.matriculaAluno = matriculaAluno;
	}
	public double getP1() {
		return p1;
	}
	public void setP1(double p1) {
		this.p1 = p1;
	}
	public double getP2() {
		return p2;
	}
	public void setP2(double p2) {
		this.p2 = p2;
	}
	public double getP3() {
		return p3;
	}
	public void setP3(double p3) {
		this.p3 = p3;
	}
	public double getP4() {
		return p4;
	}
	public void setP4(double p4) {
		this.p4 = p4;
	}
	public double getMedial_final() {
		return medial_final;
	}
	public void setMedial_final(double medial_final) {
		this.medial_final = medial_final;
	}
	public byte getFaltas() {
		return faltas;
	}
	public void setFaltas(byte faltas) {
		this.faltas = faltas;
	}
	public boolean isAprovado() {
		return aprovado;
	}
	public void setAprovado(boolean aprovado) {
		this.aprovado = aprovado;
	}
	@Override
	public String toString() {
		return "Turma_has_AlunoBEAN [idTurma=" + idTurma + ", matriculaAluno=" + matriculaAluno + ", p1=" + p1 + ", p2="
				+ p2 + ", p3=" + p3 + ", p4=" + p4 + ", medial_final=" + medial_final + ", faltas=" + faltas
				+ ", aprovado=" + aprovado + ", nomeAluno=" + nomeAluno + "]";
	}
	
	
}

package bean;

public class AlunoBEAN extends PessoaBEAN{
	private String rg;

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		if(rg != null)
		{	
			this.rg = rg;
		}else {
			this.rg = "RG padr�o";
		}	
		
	}

	@Override
	public String toString() {
		return "AlunoBEAN [rg=" + rg + "]";
	}
	
	
}

package bean;

public class AlunoBEAN extends PessoaBEAN{
	private String rg;

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	@Override
	public String toString() {
		return "AlunoBEAN [rg=" + rg + super.toString()+"]";
	}
	
	
}

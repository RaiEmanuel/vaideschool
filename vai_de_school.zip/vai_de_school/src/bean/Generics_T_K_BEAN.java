package bean;

import java.util.ArrayList;
import java.util.List;

public class Generics_T_K_BEAN<T, K> {
			List<T> listaT = new ArrayList<>();
			List<K> listaK = new ArrayList<>();
			public List<T> getListaT() {
				return listaT;
			}
			public void setListaT(List<T> listaT) {
				this.listaT = listaT;
			}
			public List<K> getListaK() {
				return listaK;
			}
			public void setListaK(List<K> listaK) {
				this.listaK = listaK;
			}
}

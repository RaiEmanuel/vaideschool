package bean;

public class ProfessorBEAN extends PessoaBEAN{

}

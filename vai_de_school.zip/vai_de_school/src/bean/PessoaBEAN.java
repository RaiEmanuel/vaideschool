package bean;

public abstract class PessoaBEAN {
	private long matricula;
	private String nome, rua, bairro, nivelAcesso, senha;
	private short numero;
	
	public long getMatricula() {
		return matricula;
	}
	public void setMatricula(long matricula) {
		if(matricula > 0) {
			this.matricula = matricula;
		}
		else
		{
			matricula = 0;
		}
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		if(nome !=null)
		{
			this.nome = nome;
		}else
		{
			this.nome = "Default";
		}
		
	}
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		if(rua != null)
		{
			this.rua = rua;
		}
		else {
			this.rua = "Rua Padr�o";
		}
		
	}

	public short getNumero() {
		return numero;
	}
	public void setNumero(short numero) {
		if(numero > 0)
		{
			this.numero = numero;
		}
		else {
			this.numero = 0;
		}
		
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		if(bairro != null)
		{
			this.bairro = bairro;
		}
		else {
			this.bairro = "Bairro padr�o";
		}
	}
	public String getNivelAcesso() {
		return nivelAcesso;
	}
	public void setNivelAcesso(String nivelAcesso) {
		if(nivelAcesso != null)
		this.nivelAcesso = nivelAcesso;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		if(senha != null)
		this.senha = senha;
	}
	@Override
	public String toString() {
		return "PessoaBEAN [matricula=" + matricula + ", nome=" + nome + ", rua=" + rua + ", bairro=" + bairro
				+ ", nivelAcesso=" + nivelAcesso + ", senha=" + senha + ", numero=" + numero + "]";
	}
	
	
}

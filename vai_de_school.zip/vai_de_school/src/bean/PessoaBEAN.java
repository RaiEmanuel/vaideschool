package bean;

public abstract class PessoaBEAN {
	private long matricula;
	private String nome, rua, bairro, nivelAcesso, senha;
	private short numero;
	
	public long getMatricula() {
		return matricula;
	}
	public void setMatricula(long matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}

	public short getNumero() {
		return numero;
	}
	public void setNumero(short numero) {
		this.numero = numero;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getNivelAcesso() {
		return nivelAcesso;
	}
	public void setNivelAcesso(String nivelAcesso) {
		this.nivelAcesso = nivelAcesso;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	@Override
	public String toString() {
		return "PessoaBEAN [matricula=" + matricula + ", nome=" + nome + ", rua=" + rua + ", bairro=" + bairro
				+ ", nivelAcesso=" + nivelAcesso + ", senha=" + senha + ", numero=" + numero + "]";
	}
	
	
}

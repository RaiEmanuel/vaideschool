package bean;

public class TurmaBEAN {
	private long idTurma, matriculaProfessor, idDisciplina;
	private String local;
	private char status;
	@Override
	public String toString() {
		return "TurmaBEAN [idTurma=" + idTurma + ", matriculaProfessor=" + matriculaProfessor + ", idDisciplina="
				+ idDisciplina + ", local=" + local + ", status=" + status + "]";
	}
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		if(idTurma > 0)
		{
			this.idTurma = idTurma;
		}else
		{
			this.idTurma = 0;
		}
	}
	public long getMatriculaProfessor() {
		return matriculaProfessor;
	}
	public void setMatriculaProfessor(long matriculaProfessor) {
		if(matriculaProfessor > 0)
		{
			this.matriculaProfessor = matriculaProfessor;
		}else
		{
			this.matriculaProfessor = 0;
		}
		
	}
	public long getIdDisciplina() {
		return idDisciplina;
	}
	public void setIdDisciplina(long idDisciplina) {
		if(idDisciplina > 0)
		{
			this.idDisciplina = idDisciplina;
		}
		else {
			this.idDisciplina = 0;
		}
		
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		if(local != null)
		{
			this.local = local;
		}else {
			this.local = "Padr�o";
		}
		
	}
	public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		if(status != ' ')
		{
			this.status = status;
		}else {
			this.status = 'A';
		}
		
	}
}

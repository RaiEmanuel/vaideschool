package bean;

public class TurmaBEAN {
	private long idTurma, matriculaProfessor, idDisciplina;
	private String local;
	private char status;
	@Override
	public String toString() {
		return "TurmaBEAN [idTurma=" + idTurma + ", matriculaProfessor=" + matriculaProfessor + ", idDisciplina="
				+ idDisciplina + ", local=" + local + ", status=" + status + "]";
	}
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		this.idTurma = idTurma;
	}
	public long getMatriculaProfessor() {
		return matriculaProfessor;
	}
	public void setMatriculaProfessor(long matriculaProfessor) {
		this.matriculaProfessor = matriculaProfessor;
	}
	public long getIdDisciplina() {
		return idDisciplina;
	}
	public void setIdDisciplina(long idDisciplina) {
		this.idDisciplina = idDisciplina;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		this.status = status;
	}
}

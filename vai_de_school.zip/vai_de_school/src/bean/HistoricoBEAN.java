package bean;

public class HistoricoBEAN {
	////aluno.nome, professor.nome, disciplina.nome, p1, p2, p3, p4, media_final, faltas, aprovado, turma.status
	private String nomeALuno, nomeProfessor, disciplina;
	private double p1, p2, p3, p4, media;
	private byte faltas;
	private boolean aprovado;
	private char Status;
	@Override
	public String toString() {
		return "HistoricoBEAN [nomeALuno=" + nomeALuno + ", nomeProfessor=" + nomeProfessor + ", disciplina="
				+ disciplina + ", p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + ", p4=" + p4 + ", media=" + media
				+ ", faltas=" + faltas + ", aprovado=" + aprovado + ", Status=" + Status + "]";
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public String getNomeALuno() {
		return nomeALuno;
	}
	public void setNomeALuno(String nomeALuno) {
		this.nomeALuno = nomeALuno;
	}
	public String getNomeProfessor() {
		return nomeProfessor;
	}
	public void setNomeProfessor(String nomeProfessor) {
		this.nomeProfessor = nomeProfessor;
	}
	public double getP1() {
		return p1;
	}
	public void setP1(double p1) {
		this.p1 = p1;
	}
	public double getP2() {
		return p2;
	}
	public void setP2(double p2) {
		this.p2 = p2;
	}
	public double getP3() {
		return p3;
	}
	public void setP3(double p3) {
		this.p3 = p3;
	}
	public double getP4() {
		return p4;
	}
	public void setP4(double p4) {
		this.p4 = p4;
	}
	public double getMedia() {
		return media;
	}
	public void setMedia(double media) {
		this.media = media;
	}
	public byte getFaltas() {
		return faltas;
	}
	public void setFaltas(byte faltas) {
		this.faltas = faltas;
	}
	public boolean isAprovado() {
		return aprovado;
	}
	public void setAprovado(boolean aprovado) {
		this.aprovado = aprovado;
	}
	public char getStatus() {
		return Status;
	}
	public void setStatus(char status) {
		Status = status;
	}
}

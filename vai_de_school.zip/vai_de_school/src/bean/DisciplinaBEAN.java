package bean;

public class DisciplinaBEAN {
	private long idDisciplina;
	private String nome;
	private byte carga_horaria, hora_aula;
	public long getIdDisciplina() {
		return idDisciplina;
	}
	public void setIdDisciplina(long idDisciplina) {
		this.idDisciplina = idDisciplina;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public byte getCarga_horaria() {
		return carga_horaria;
	}
	public void setCarga_horaria(byte carga_horaria) {
		this.carga_horaria = carga_horaria;
	}
	public byte getHora_aula() {
		return hora_aula;
	}
	public void setHora_aula(byte hora_aula) {
		this.hora_aula = hora_aula;
	}
	@Override
	public String toString() {
		return "DisciplinaBEAN [idDisciplina=" + idDisciplina + ", nome=" + nome + ", carga_horaria=" + carga_horaria
				+ ", hora_aula=" + hora_aula + "]";
	}
	
	
	
}

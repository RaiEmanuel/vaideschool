package bean;

public class DisciplinaBEAN {
	private long idDisciplina;
	private String nome;
	private byte carga_horaria, hora_aula;
	public long getIdDisciplina() {
		return idDisciplina;
	}
	public void setIdDisciplina(long idDisciplina) {
		if(idDisciplina > 0)
		{
			this.idDisciplina = idDisciplina;
		}else
		{
			this.idDisciplina = 0;
		}
		
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		if(nome != null)
		{
			this.nome = nome;
		}else {
			this.nome = "Padr�o";
		}
		
	}
	public byte getCarga_horaria() {
		return carga_horaria;
	}
	public void setCarga_horaria(byte carga_horaria) {
		if(carga_horaria > 0)
		{
			this.carga_horaria = carga_horaria;
		}
		else {
			carga_horaria = 1;
		}
		
	}
	public byte getHora_aula() {
		return hora_aula;
	}
	public void setHora_aula(byte hora_aula) {
		if(hora_aula > 0) {
			this.hora_aula = hora_aula;
		}else {
			this.hora_aula = 1;
		}
		
	}
	@Override
	public String toString() {
		return "DisciplinaBEAN [idDisciplina=" + idDisciplina + ", nome=" + nome + ", carga_horaria=" + carga_horaria
				+ ", hora_aula=" + hora_aula + "]";
	}
	
	
	
}

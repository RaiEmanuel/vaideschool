package bean;


public class DataTableViewHomeProfessorBEAN{
	private String disciplina, local, horario;
	private long idProfessorLogado, idTurma;
	
	public String getDisciplina() {
		return disciplina;
	}
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		this.idTurma = idTurma;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}
	public long getIdProfessorLogado() {
		return idProfessorLogado;
	}
	public void setIdProfessorLogado(long idProfessorLogado) {
		this.idProfessorLogado = idProfessorLogado;
	}
	@Override
	public String toString() {
		return "DataTableViewHomeProfessorBEAN [disciplina=" + disciplina + ", local=" + local + ", horario=" + horario
				+ ", idProfessorLogado=" + idProfessorLogado + ", idTurma=" + idTurma + "]";
	}

	
	
	
	
}

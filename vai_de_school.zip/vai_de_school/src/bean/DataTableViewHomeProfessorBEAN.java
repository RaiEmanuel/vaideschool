package bean;

import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;

public class DataTableViewHomeProfessorBEAN {
	private SimpleStringProperty disciplina, local, horario;
	private SimpleLongProperty idProfessorLogado;

	public String getDisciplina() {
		return disciplina.get();
	}

	public void setDisciplina(SimpleStringProperty disciplina) {
		this.disciplina = disciplina;
	}

	
	
	public Long getIdProfessorLogado() {
		return idProfessorLogado.get();
	}

	public void setIdProfessorLogado(SimpleLongProperty idProfessorLogado) {
		this.idProfessorLogado = idProfessorLogado;
	}

	public String getLocal() {
		return local.get();
	}

	public void setLocal(SimpleStringProperty local) {
		this.local = local;
	}

	public String getHorario() {
		return horario.get();
	}

	public void setHorario(SimpleStringProperty horario) {
		this.horario = horario;
	}


	@Override
	public String toString() {
		return "DataTableViewHomeProfessorBEAN [disciplina=" + disciplina + ", local=" + local + ", horario=" + horario
				+ ", idProfessorLogado=" + idProfessorLogado + "]";
	}

	
	
	
}

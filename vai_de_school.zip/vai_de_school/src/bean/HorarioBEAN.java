package bean;

public class HorarioBEAN {
	private long idHorario, idTurma;
	private String horario;
	public long getIdHorario() {
		return idHorario;
	}
	public void setIdHorario(long idHorario) {
		if(idHorario > 0)
		{
			this.idHorario = idHorario;
		}else
		{
			this.idHorario = 0;
		}
		
	}
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		if(idTurma > 0)
		{
			this.idTurma = idTurma;
		}
		else {
			idTurma = 0;
		}
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		if(horario != null)
		{
			this.horario = horario;
		}
		else {
			this.horario = "Hor�rio padr�o";
		}
		
	}
	@Override
	public String toString() {
		return "HorarioBEAN [idHorario=" + idHorario + ", idTurma=" + idTurma + ", horario=" + horario + "]";
	}
	
	
}

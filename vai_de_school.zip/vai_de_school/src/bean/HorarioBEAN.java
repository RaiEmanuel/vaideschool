package bean;

public class HorarioBEAN {
	private long idHorario, idTurma;
	private String horario;
	public long getIdHorario() {
		return idHorario;
	}
	public void setIdHorario(long idHorario) {
		this.idHorario = idHorario;
	}
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		this.idTurma = idTurma;
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}
	@Override
	public String toString() {
		return "HorarioBEAN [idHorario=" + idHorario + ", idTurma=" + idTurma + ", horario=" + horario + "]";
	}
	
	
}

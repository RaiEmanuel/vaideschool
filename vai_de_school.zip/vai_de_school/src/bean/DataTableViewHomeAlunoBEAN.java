package bean;

import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;

public class DataTableViewHomeAlunoBEAN {
	private SimpleStringProperty disciplina, local, horario, professor;
	private SimpleLongProperty idAlunoLogado;

	public String getDisciplina() {
		return disciplina.get();
	}

	public void setDisciplina(SimpleStringProperty disciplina) {
		this.disciplina = disciplina;
	}

	
	
	public Long getIdAlunoLogado() {
		return idAlunoLogado.get();
	}

	public void setIdAlunoLogado(SimpleLongProperty idAlunoLogado) {
		this.idAlunoLogado = idAlunoLogado;
	}

	public String getLocal() {
		return local.get();
	}

	public void setLocal(SimpleStringProperty local) {
		this.local = local;
	}

	public String getHorario() {
		return horario.get();
	}

	public void setHorario(SimpleStringProperty horario) {
		this.horario = horario;
	}

	public String getProfessor() {
		return professor.get();
	}

	public void setProfessor(SimpleStringProperty professor) {
		this.professor = professor;
	}

	@Override
	public String toString() {
		return "DataTableViewHomeAlunoBEAN [disciplina=" + disciplina + ", local=" + local + ", horario=" + horario
				+ ", professor=" + professor + ", idAlunoLogado=" + idAlunoLogado + "]";
	}

	
	
	
}

package bean;

import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;

public class DataTableViewHomeAlunoBEAN {
	private String disciplina, local, horario, professor;
	private long idAlunoLogado, idTurma;
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}
	public String getProfessor() {
		return professor;
	}
	public void setProfessor(String professor) {
		this.professor = professor;
	}
	public long getIdAlunoLogado() {
		return idAlunoLogado;
	}
	public void setIdAlunoLogado(long idAlunoLogado) {
		this.idAlunoLogado = idAlunoLogado;
	}
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		this.idTurma = idTurma;
	}
	@Override
	public String toString() {
		return "DataTableViewHomeAlunoBEAN [disciplina=" + disciplina + ", local=" + local + ", horario=" + horario
				+ ", professor=" + professor + ", idAlunoLogado=" + idAlunoLogado + ", idTurma=" + idTurma + "]";
	}


}

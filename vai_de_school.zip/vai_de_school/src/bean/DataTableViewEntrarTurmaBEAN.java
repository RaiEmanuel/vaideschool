package bean;

public class DataTableViewEntrarTurmaBEAN {
	private String disciplina, local, horario, professor;
	private long idTurma;
	
	public long getIdTurma() {
		return idTurma;
	}
	public void setIdTurma(long idTurma) {
		this.idTurma = idTurma;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}
	public String getProfessor() {
		return professor;
	}
	public void setProfessor(String professor) {
		this.professor = professor;
	}
	
	@Override
	public String toString() {
		return "DataTableViewEntrarTurmaBEAN [disciplina=" + disciplina + ", local=" + local + ", horario=" + horario
				+ ", professor=" + professor + ", idTurma=" + idTurma + "]";
	}
		
}
